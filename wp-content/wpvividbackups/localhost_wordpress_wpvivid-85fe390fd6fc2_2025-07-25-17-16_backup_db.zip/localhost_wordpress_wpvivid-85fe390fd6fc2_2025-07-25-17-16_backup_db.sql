/* # site_url: http://localhost/wordpress */;
/* # home_url: http://localhost/wordpress */;
/* # content_url: http://localhost/wordpress/wp-content */;
/* # upload_url: http://localhost/wordpress/wp-content/uploads */;
/* # table_prefix: wp_ */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_links` (
  `link_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint unsigned NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES (1,1,0);
INSERT INTO `wp_term_relationships` VALUES (15,3,0);
INSERT INTO `wp_term_relationships` VALUES (17,2,0);
INSERT INTO `wp_term_relationships` VALUES (20,4,0);
INSERT INTO `wp_term_relationships` VALUES (22,2,0);
INSERT INTO `wp_term_relationships` VALUES (24,3,0);
INSERT INTO `wp_term_relationships` VALUES (25,5,0);
INSERT INTO `wp_term_relationships` VALUES (26,5,0);
INSERT INTO `wp_term_relationships` VALUES (33,5,0);
INSERT INTO `wp_term_relationships` VALUES (34,5,0);
INSERT INTO `wp_term_relationships` VALUES (35,5,0);
INSERT INTO `wp_term_relationships` VALUES (41,4,0);
INSERT INTO `wp_term_relationships` VALUES (43,3,0);
INSERT INTO `wp_term_relationships` VALUES (45,3,0);
INSERT INTO `wp_term_relationships` VALUES (48,4,0);
INSERT INTO `wp_term_relationships` VALUES (50,4,0);
INSERT INTO `wp_term_relationships` VALUES (55,4,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint unsigned NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (1,1,'category','',0,1);
INSERT INTO `wp_term_taxonomy` VALUES (2,2,'property_type','',0,2);
INSERT INTO `wp_term_taxonomy` VALUES (3,3,'property_type','',0,4);
INSERT INTO `wp_term_taxonomy` VALUES (4,4,'property_type','',0,5);
INSERT INTO `wp_term_taxonomy` VALUES (5,5,'nav_menu','',0,5);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_termmeta`
--

LOCK TABLES `wp_termmeta` WRITE;
/*!40000 ALTER TABLE `wp_termmeta` DISABLE KEYS */;
INSERT INTO `wp_termmeta` VALUES (1,2,'property_type_image','https://www.pexels.com/photo/assorted-color-wall-paint-house-photo-1370704/');
INSERT INTO `wp_termmeta` VALUES (2,3,'property_type_image','');
INSERT INTO `wp_termmeta` VALUES (3,4,'property_type_image','');
/*!40000 ALTER TABLE `wp_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES (1,'Uncategorized','uncategorized',0);
INSERT INTO `wp_terms` VALUES (2,'Apartments','apartments',0);
INSERT INTO `wp_terms` VALUES (3,'House','house',0);
INSERT INTO `wp_terms` VALUES (4,'Villa','villa',0);
INSERT INTO `wp_terms` VALUES (5,'Main Menu','main-menu',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES (1,1,'nickname','root');
INSERT INTO `wp_usermeta` VALUES (2,1,'first_name','');
INSERT INTO `wp_usermeta` VALUES (3,1,'last_name','');
INSERT INTO `wp_usermeta` VALUES (4,1,'description','');
INSERT INTO `wp_usermeta` VALUES (5,1,'rich_editing','true');
INSERT INTO `wp_usermeta` VALUES (6,1,'syntax_highlighting','true');
INSERT INTO `wp_usermeta` VALUES (7,1,'comment_shortcuts','false');
INSERT INTO `wp_usermeta` VALUES (8,1,'admin_color','fresh');
INSERT INTO `wp_usermeta` VALUES (9,1,'use_ssl','0');
INSERT INTO `wp_usermeta` VALUES (10,1,'show_admin_bar_front','true');
INSERT INTO `wp_usermeta` VALUES (11,1,'locale','');
INSERT INTO `wp_usermeta` VALUES (12,1,'wp_capabilities','a:1:{s:13:"administrator";b:1;}');
INSERT INTO `wp_usermeta` VALUES (13,1,'wp_user_level','10');
INSERT INTO `wp_usermeta` VALUES (14,1,'dismissed_wp_pointers','theme_editor_notice');
INSERT INTO `wp_usermeta` VALUES (15,1,'show_welcome_panel','1');
INSERT INTO `wp_usermeta` VALUES (16,1,'session_tokens','a:1:{s:64:"62d26d3eb2b6dd8000df77a8b109b274244f3a847744d404ef938dcd634d5919";a:4:{s:10:"expiration";i:1753537830;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36";s:5:"login";i:1753365030;}}');
INSERT INTO `wp_usermeta` VALUES (17,1,'wp_dashboard_quick_press_last_post_id','6');
INSERT INTO `wp_usermeta` VALUES (18,1,'wp_persisted_preferences','a:3:{s:4:"core";a:2:{s:26:"isComplementaryAreaVisible";b:1;s:10:"openPanels";a:2:{i:0;s:11:"post-status";i:1;s:28:"taxonomy-panel-property_type";}}s:14:"core/edit-post";a:1:{s:12:"welcomeGuide";b:0;}s:9:"_modified";s:24:"2025-07-20T07:48:19.111Z";}');
INSERT INTO `wp_usermeta` VALUES (19,1,'wp_user-settings','libraryContent=browse');
INSERT INTO `wp_usermeta` VALUES (20,1,'wp_user-settings-time','1752999385');
INSERT INTO `wp_usermeta` VALUES (21,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}');
INSERT INTO `wp_usermeta` VALUES (22,1,'metaboxhidden_nav-menus','a:2:{i:0;s:22:"add-post-type-property";i:1;s:12:"add-post_tag";}');
INSERT INTO `wp_usermeta` VALUES (23,1,'nav_menu_recently_edited','5');
INSERT INTO `wp_usermeta` VALUES (24,1,'meta-box-order_property','a:3:{s:4:"side";s:39:"submitdiv,property_typediv,postimagediv";s:6:"normal";s:24:"property_details,slugdiv";s:8:"advanced";s:36:"property_gallery,realestate_featured";}');
INSERT INTO `wp_usermeta` VALUES (25,1,'screen_layout_property','2');
INSERT INTO `wp_usermeta` VALUES (26,1,'closedpostboxes_property','a:0:{}');
INSERT INTO `wp_usermeta` VALUES (27,1,'metaboxhidden_property','a:1:{i:0;s:7:"slugdiv";}');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES (1,'root','$wp$2y$10$o10Q8iRzk1CYUbqklgs1Ruqe9Wgux6jSs8oCsVuLuieQ9awLFRSny','root','joycoolxx@gmail.com','http://localhost/wordpress','2025-07-19 21:00:27','',0,'root');
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
INSERT INTO `wp_comments` VALUES (1,1,'A WordPress Commenter','wapuu@wordpress.example','https://wordpress.org/','','2025-07-19 21:00:27','2025-07-19 21:00:27','Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com/">Gravatar</a>.',0,'1','','comment',0,0);
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES (1,2,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (2,3,'_wp_page_template','default');
INSERT INTO `wp_postmeta` VALUES (3,7,'_edit_lock','1752991591:1');
INSERT INTO `wp_postmeta` VALUES (5,9,'_wp_attached_file','2025/07/Apart_1.jpg');
INSERT INTO `wp_postmeta` VALUES (6,9,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:19:"2025/07/Apart_1.jpg";s:8:"filesize";i:72780;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (7,10,'_wp_attached_file','2025/07/Apart_2.jpg');
INSERT INTO `wp_postmeta` VALUES (8,10,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:19:"2025/07/Apart_2.jpg";s:8:"filesize";i:81309;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (18,11,'_edit_lock','1753004242:1');
INSERT INTO `wp_postmeta` VALUES (19,12,'_wp_attached_file','2025/07/3.png');
INSERT INTO `wp_postmeta` VALUES (20,12,'_wp_attachment_metadata','a:6:{s:5:"width";i:160;s:6:"height";i:160;s:4:"file";s:13:"2025/07/3.png";s:8:"filesize";i:12753;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (21,11,'_thumbnail_id','12');
INSERT INTO `wp_postmeta` VALUES (22,11,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (23,13,'_edit_lock','1753004296:1');
INSERT INTO `wp_postmeta` VALUES (24,14,'_wp_attached_file','2025/07/istockphoto-1165538334-2048x2048-1.jpg');
INSERT INTO `wp_postmeta` VALUES (25,14,'_wp_attachment_metadata','a:6:{s:5:"width";i:2048;s:6:"height";i:1365;s:4:"file";s:46:"2025/07/istockphoto-1165538334-2048x2048-1.jpg";s:8:"filesize";i:298267;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:24:"Getty Images/iStockphoto";s:6:"camera";s:0:"";s:7:"caption";s:138:"Close-up portrait of his he nice attractive discontent guilty bearded guy isolated, over bright vivid shine violet lilac purple background";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (26,13,'_thumbnail_id','14');
INSERT INTO `wp_postmeta` VALUES (27,13,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (28,15,'_edit_lock','1753427652:1');
INSERT INTO `wp_postmeta` VALUES (29,16,'_wp_attached_file','2025/07/Apart_4.jpg');
INSERT INTO `wp_postmeta` VALUES (30,16,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:19:"2025/07/Apart_4.jpg";s:8:"filesize";i:82253;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (31,15,'_thumbnail_id','39');
INSERT INTO `wp_postmeta` VALUES (32,15,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (33,15,'property_price','45,00,000');
INSERT INTO `wp_postmeta` VALUES (34,15,'property_location','Dhanbad');
INSERT INTO `wp_postmeta` VALUES (35,15,'property_bedrooms','5');
INSERT INTO `wp_postmeta` VALUES (36,15,'property_bathrooms','2');
INSERT INTO `wp_postmeta` VALUES (37,15,'property_area','1200');
INSERT INTO `wp_postmeta` VALUES (38,15,'property_status','for-sale');
INSERT INTO `wp_postmeta` VALUES (39,15,'featured_property','yes');
INSERT INTO `wp_postmeta` VALUES (40,17,'_edit_lock','1753427634:1');
INSERT INTO `wp_postmeta` VALUES (41,18,'_wp_attached_file','2025/07/pexels-bluerhinomedia-3663530.jpeg');
INSERT INTO `wp_postmeta` VALUES (42,18,'_wp_attachment_metadata','a:6:{s:5:"width";i:500;s:6:"height";i:800;s:4:"file";s:42:"2025/07/pexels-bluerhinomedia-3663530.jpeg";s:8:"filesize";i:103366;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (43,17,'_thumbnail_id','19');
INSERT INTO `wp_postmeta` VALUES (44,17,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (45,17,'property_price','95,00,000');
INSERT INTO `wp_postmeta` VALUES (46,17,'property_location','Delhi');
INSERT INTO `wp_postmeta` VALUES (47,17,'property_bedrooms','3');
INSERT INTO `wp_postmeta` VALUES (48,17,'property_bathrooms','1');
INSERT INTO `wp_postmeta` VALUES (49,17,'property_area','1450');
INSERT INTO `wp_postmeta` VALUES (50,17,'property_status','for-sale');
INSERT INTO `wp_postmeta` VALUES (51,17,'featured_property','yes');
INSERT INTO `wp_postmeta` VALUES (52,19,'_wp_attached_file','2025/07/pexels-bluerhinomedia-3663530-1.jpeg');
INSERT INTO `wp_postmeta` VALUES (53,19,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:44:"2025/07/pexels-bluerhinomedia-3663530-1.jpeg";s:8:"filesize";i:102322;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (54,20,'_edit_lock','1753427607:1');
INSERT INTO `wp_postmeta` VALUES (55,21,'_wp_attached_file','2025/07/pexels-pixabay-415687.jpeg');
INSERT INTO `wp_postmeta` VALUES (56,21,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:34:"2025/07/pexels-pixabay-415687.jpeg";s:8:"filesize";i:161968;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (57,20,'_thumbnail_id','21');
INSERT INTO `wp_postmeta` VALUES (58,20,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (59,20,'property_price','1,65,00,00');
INSERT INTO `wp_postmeta` VALUES (60,20,'property_location','Lonavala, Maharashtra');
INSERT INTO `wp_postmeta` VALUES (61,20,'property_bedrooms','4');
INSERT INTO `wp_postmeta` VALUES (62,20,'property_bathrooms','2');
INSERT INTO `wp_postmeta` VALUES (63,20,'property_area','1200');
INSERT INTO `wp_postmeta` VALUES (64,20,'property_status','for-sale');
INSERT INTO `wp_postmeta` VALUES (65,20,'featured_property','yes');
INSERT INTO `wp_postmeta` VALUES (66,22,'_edit_lock','1753427572:1');
INSERT INTO `wp_postmeta` VALUES (67,23,'_wp_attached_file','2025/07/pexels-myatezhny39-2422433.jpeg');
INSERT INTO `wp_postmeta` VALUES (68,23,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:39:"2025/07/pexels-myatezhny39-2422433.jpeg";s:8:"filesize";i:154300;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (69,22,'_thumbnail_id','23');
INSERT INTO `wp_postmeta` VALUES (70,22,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (71,22,'property_price','8,50,00,000');
INSERT INTO `wp_postmeta` VALUES (72,22,'property_location','Altamount Road, Mumbai');
INSERT INTO `wp_postmeta` VALUES (73,22,'property_bedrooms','4');
INSERT INTO `wp_postmeta` VALUES (74,22,'property_bathrooms','2');
INSERT INTO `wp_postmeta` VALUES (75,22,'property_area','3800');
INSERT INTO `wp_postmeta` VALUES (76,22,'property_status','for-sale');
INSERT INTO `wp_postmeta` VALUES (77,22,'featured_property','yes');
INSERT INTO `wp_postmeta` VALUES (81,24,'_edit_lock','1753427281:1');
INSERT INTO `wp_postmeta` VALUES (82,24,'_thumbnail_id','38');
INSERT INTO `wp_postmeta` VALUES (83,24,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (84,24,'property_price','43,00,000');
INSERT INTO `wp_postmeta` VALUES (85,24,'property_location','Dhanbad, Jharkhand');
INSERT INTO `wp_postmeta` VALUES (86,24,'property_bedrooms','6');
INSERT INTO `wp_postmeta` VALUES (87,24,'property_bathrooms','2');
INSERT INTO `wp_postmeta` VALUES (88,24,'property_area','2750');
INSERT INTO `wp_postmeta` VALUES (89,24,'property_status','for-sale');
INSERT INTO `wp_postmeta` VALUES (90,24,'featured_property','yes');
INSERT INTO `wp_postmeta` VALUES (91,25,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (92,25,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (93,25,'_menu_item_object_id','25');
INSERT INTO `wp_postmeta` VALUES (94,25,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (95,25,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (96,25,'_menu_item_classes','a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (97,25,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (98,25,'_menu_item_url','http://localhost/wordpress/');
INSERT INTO `wp_postmeta` VALUES (100,26,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (101,26,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (102,26,'_menu_item_object_id','2');
INSERT INTO `wp_postmeta` VALUES (103,26,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (104,26,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (105,26,'_menu_item_classes','a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (106,26,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (107,26,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (109,27,'_edit_lock','1753026438:1');
INSERT INTO `wp_postmeta` VALUES (110,29,'_edit_lock','1753026457:1');
INSERT INTO `wp_postmeta` VALUES (111,31,'_edit_lock','1753026471:1');
INSERT INTO `wp_postmeta` VALUES (112,33,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (113,33,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (114,33,'_menu_item_object_id','31');
INSERT INTO `wp_postmeta` VALUES (115,33,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (116,33,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (117,33,'_menu_item_classes','a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (118,33,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (119,33,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (121,34,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (122,34,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (123,34,'_menu_item_object_id','29');
INSERT INTO `wp_postmeta` VALUES (124,34,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (125,34,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (126,34,'_menu_item_classes','a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (127,34,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (128,34,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (130,35,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (131,35,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (132,35,'_menu_item_object_id','27');
INSERT INTO `wp_postmeta` VALUES (133,35,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (134,35,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (135,35,'_menu_item_classes','a:1:{i:0;s:0:"";}');
INSERT INTO `wp_postmeta` VALUES (136,35,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (137,35,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (139,24,'_price','43,00,000');
INSERT INTO `wp_postmeta` VALUES (140,24,'_location','Dhanbad, Jharkhand');
INSERT INTO `wp_postmeta` VALUES (141,24,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (142,24,'_area','2,750');
INSERT INTO `wp_postmeta` VALUES (143,22,'_price','8,50,00,000');
INSERT INTO `wp_postmeta` VALUES (144,22,'_location','Altamount Road, Mumbai');
INSERT INTO `wp_postmeta` VALUES (145,22,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (146,22,'_area','3,800');
INSERT INTO `wp_postmeta` VALUES (147,20,'_price','1,65,00,000');
INSERT INTO `wp_postmeta` VALUES (148,20,'_location','Lonavala, Maharashtra');
INSERT INTO `wp_postmeta` VALUES (149,20,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (150,20,'_area','2,200');
INSERT INTO `wp_postmeta` VALUES (151,17,'_price','98,00,000');
INSERT INTO `wp_postmeta` VALUES (152,17,'_location','Bengaluru, Karnataka');
INSERT INTO `wp_postmeta` VALUES (153,17,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (154,17,'_area','1,450');
INSERT INTO `wp_postmeta` VALUES (155,15,'_price','32,00,000');
INSERT INTO `wp_postmeta` VALUES (156,15,'_location','Hinjewadi, Pune, Maharashtra');
INSERT INTO `wp_postmeta` VALUES (157,15,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (158,15,'_area','1,180');
INSERT INTO `wp_postmeta` VALUES (159,25,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (160,26,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (161,33,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (162,34,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (163,35,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (164,38,'_wp_attached_file','2025/07/pexels-atomlaborblog-1105754.jpeg');
INSERT INTO `wp_postmeta` VALUES (165,38,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:41:"2025/07/pexels-atomlaborblog-1105754.jpeg";s:8:"filesize";i:120015;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (166,24,'_is_featured','1');
INSERT INTO `wp_postmeta` VALUES (167,39,'_wp_attached_file','2025/07/pexels-pixabay-210617.jpeg');
INSERT INTO `wp_postmeta` VALUES (168,39,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:34:"2025/07/pexels-pixabay-210617.jpeg";s:8:"filesize";i:135939;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (169,15,'_is_featured','1');
INSERT INTO `wp_postmeta` VALUES (170,41,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (171,41,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (172,41,'_edit_lock','1753427251:1');
INSERT INTO `wp_postmeta` VALUES (173,42,'_wp_attached_file','2025/07/pexels-william-lemond-25283-105933.jpeg');
INSERT INTO `wp_postmeta` VALUES (174,42,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:47:"2025/07/pexels-william-lemond-25283-105933.jpeg";s:8:"filesize";i:149967;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (175,41,'_thumbnail_id','42');
INSERT INTO `wp_postmeta` VALUES (176,41,'_price','1,90,00,000');
INSERT INTO `wp_postmeta` VALUES (177,41,'_location','Anjuna, North Goa');
INSERT INTO `wp_postmeta` VALUES (178,41,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (179,41,'_area','3800');
INSERT INTO `wp_postmeta` VALUES (180,43,'_is_featured','1');
INSERT INTO `wp_postmeta` VALUES (181,43,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (182,43,'_edit_lock','1753427225:1');
INSERT INTO `wp_postmeta` VALUES (183,44,'_wp_attached_file','2025/07/Apart9.jpeg');
INSERT INTO `wp_postmeta` VALUES (184,44,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:19:"2025/07/Apart9.jpeg";s:8:"filesize";i:163226;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (185,43,'_thumbnail_id','44');
INSERT INTO `wp_postmeta` VALUES (186,43,'_price','1,40,00,000');
INSERT INTO `wp_postmeta` VALUES (187,43,'_location','Dehradun, Uttarakhand');
INSERT INTO `wp_postmeta` VALUES (188,43,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (189,43,'_area','1,800');
INSERT INTO `wp_postmeta` VALUES (190,45,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (191,45,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (192,45,'_edit_lock','1753459188:1');
INSERT INTO `wp_postmeta` VALUES (193,46,'_wp_attached_file','2025/07/Aprt10.jpeg');
INSERT INTO `wp_postmeta` VALUES (194,46,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:19:"2025/07/Aprt10.jpeg";s:8:"filesize";i:143100;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (195,45,'_thumbnail_id','46');
INSERT INTO `wp_postmeta` VALUES (196,45,'_price','39,00,000');
INSERT INTO `wp_postmeta` VALUES (197,45,'_location','Khandala, Lonavala, Maharashtra');
INSERT INTO `wp_postmeta` VALUES (198,45,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (199,45,'_area','600');
INSERT INTO `wp_postmeta` VALUES (200,47,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (201,25,'_wp_old_date','2025-07-20');
INSERT INTO `wp_postmeta` VALUES (202,26,'_wp_old_date','2025-07-20');
INSERT INTO `wp_postmeta` VALUES (203,33,'_wp_old_date','2025-07-20');
INSERT INTO `wp_postmeta` VALUES (204,34,'_wp_old_date','2025-07-20');
INSERT INTO `wp_postmeta` VALUES (205,35,'_wp_old_date','2025-07-20');
INSERT INTO `wp_postmeta` VALUES (206,48,'_is_featured','1');
INSERT INTO `wp_postmeta` VALUES (207,48,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (208,48,'_edit_lock','1753427046:1');
INSERT INTO `wp_postmeta` VALUES (209,49,'_wp_attached_file','2025/07/name.jpg');
INSERT INTO `wp_postmeta` VALUES (210,49,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:16:"2025/07/name.jpg";s:8:"filesize";i:151573;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (211,48,'_thumbnail_id','49');
INSERT INTO `wp_postmeta` VALUES (212,48,'_price','3,70,00,000');
INSERT INTO `wp_postmeta` VALUES (213,48,'_location','Gachibowli, Hyderabad, Telangana');
INSERT INTO `wp_postmeta` VALUES (214,48,'_status','Under Construction');
INSERT INTO `wp_postmeta` VALUES (215,48,'_area','2700');
INSERT INTO `wp_postmeta` VALUES (216,50,'_is_featured','1');
INSERT INTO `wp_postmeta` VALUES (217,50,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (218,50,'_edit_lock','1753427021:1');
INSERT INTO `wp_postmeta` VALUES (219,51,'_wp_attached_file','2025/07/pexels-fazza-36355.jpeg');
INSERT INTO `wp_postmeta` VALUES (220,51,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:31:"2025/07/pexels-fazza-36355.jpeg";s:8:"filesize";i:105164;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (221,50,'_thumbnail_id','51');
INSERT INTO `wp_postmeta` VALUES (222,50,'_price','3,40,00,000');
INSERT INTO `wp_postmeta` VALUES (223,50,'_location','Kolkata');
INSERT INTO `wp_postmeta` VALUES (224,50,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (225,50,'_area','4,600');
INSERT INTO `wp_postmeta` VALUES (226,52,'_wp_attached_file','2025/07/pexels-william-lemond-25283-105933.jpg');
INSERT INTO `wp_postmeta` VALUES (227,52,'_wp_attachment_metadata','a:6:{s:5:"width";i:4912;s:6:"height";i:3264;s:4:"file";s:46:"2025/07/pexels-william-lemond-25283-105933.jpg";s:8:"filesize";i:1741162;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (228,53,'_wp_attached_file','2025/07/pexels-pixabay-210617.jpg');
INSERT INTO `wp_postmeta` VALUES (229,53,'_wp_attachment_metadata','a:6:{s:5:"width";i:3831;s:6:"height";i:2565;s:4:"file";s:33:"2025/07/pexels-pixabay-210617.jpg";s:8:"filesize";i:1370851;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (230,54,'_wp_attached_file','2025/07/pexels-atomlaborblog-1105754.jpg');
INSERT INTO `wp_postmeta` VALUES (231,54,'_wp_attachment_metadata','a:6:{s:5:"width";i:4608;s:6:"height";i:2592;s:4:"file";s:40:"2025/07/pexels-atomlaborblog-1105754.jpg";s:8:"filesize";i:1386982;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (232,50,'_property_gallery','0');
INSERT INTO `wp_postmeta` VALUES (233,55,'_is_featured','1');
INSERT INTO `wp_postmeta` VALUES (234,55,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (235,55,'_edit_lock','1753451733:1');
INSERT INTO `wp_postmeta` VALUES (236,56,'_wp_attached_file','2025/07/pexels-nattapat-siriwan-9284-51212.jpeg');
INSERT INTO `wp_postmeta` VALUES (237,56,'_wp_attachment_metadata','a:6:{s:5:"width";i:550;s:6:"height";i:500;s:4:"file";s:47:"2025/07/pexels-nattapat-siriwan-9284-51212.jpeg";s:8:"filesize";i:108553;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}');
INSERT INTO `wp_postmeta` VALUES (238,55,'_thumbnail_id','56');
INSERT INTO `wp_postmeta` VALUES (239,55,'_price','15,00,00,000');
INSERT INTO `wp_postmeta` VALUES (240,55,'_location','Jaipur, Rajasthan');
INSERT INTO `wp_postmeta` VALUES (241,55,'_status','Ready to Move');
INSERT INTO `wp_postmeta` VALUES (242,55,'_area','4,800');
INSERT INTO `wp_postmeta` VALUES (243,55,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (244,55,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (245,55,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (261,50,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (262,50,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (263,48,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (264,48,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (265,48,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (266,45,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (267,45,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (268,45,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (269,43,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (270,43,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (271,43,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (272,41,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (273,41,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (274,41,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (275,24,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (276,24,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (277,24,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (278,22,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (279,22,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (280,22,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (281,22,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (282,20,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (283,20,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (284,20,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (285,20,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (286,17,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (287,17,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (288,17,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (289,17,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (290,15,'_map_embed','');
INSERT INTO `wp_postmeta` VALUES (291,15,'_contact_email','joycoolxx@gmail.com');
INSERT INTO `wp_postmeta` VALUES (292,15,'_property_gallery','');
INSERT INTO `wp_postmeta` VALUES (295,61,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (303,61,'_edit_lock','1753459085:1');
INSERT INTO `wp_postmeta` VALUES (304,63,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (305,64,'_is_featured','');
INSERT INTO `wp_postmeta` VALUES (306,63,'_edit_lock','1753463595:1');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES (1,1,'2025-07-19 21:00:27','2025-07-19 21:00:27','<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->','Hello world!','','publish','open','open','','hello-world','','','2025-07-19 21:00:27','2025-07-19 21:00:27','',0,'http://localhost/wordpress/?p=1',0,'post','',1);
INSERT INTO `wp_posts` VALUES (2,1,'2025-07-19 21:00:27','2025-07-19 21:00:27','<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://localhost/wordpress/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->','Sample Page','','publish','closed','open','','sample-page','','','2025-07-19 21:00:27','2025-07-19 21:00:27','',0,'http://localhost/wordpress/?page_id=2',0,'page','',0);
INSERT INTO `wp_posts` VALUES (3,1,'2025-07-19 21:00:27','2025-07-19 21:00:27','<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we are</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://localhost/wordpress.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Comments</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Media</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Embedded content from other websites</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Who we share your data with</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">How long we retain your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>\n<!-- /wp:paragraph -->\n<!-- wp:paragraph -->\n<p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">What rights you have over your data</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>\n<!-- /wp:paragraph -->\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Where your data is sent</h2>\n<!-- /wp:heading -->\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p>\n<!-- /wp:paragraph -->\n','Privacy Policy','','draft','closed','open','','privacy-policy','','','2025-07-19 21:00:27','2025-07-19 21:00:27','',0,'http://localhost/wordpress/?page_id=3',0,'page','',0);
INSERT INTO `wp_posts` VALUES (4,0,'2025-07-19 21:00:34','2025-07-19 21:00:34','<!-- wp:page-list /-->','Navigation','','publish','closed','closed','','navigation','','','2025-07-19 21:00:34','2025-07-19 21:00:34','',0,'http://localhost/wordpress/2025/07/19/navigation/',0,'wp_navigation','',0);
INSERT INTO `wp_posts` VALUES (5,0,'2025-07-19 21:00:34','2025-07-19 21:00:34','<!-- wp:page-list /-->','Navigation','','publish','closed','closed','','navigation','','','2025-07-19 21:00:34','2025-07-19 21:00:34','',0,'http://localhost/wordpress/index.php/2025/07/19/navigation/',0,'wp_navigation','',0);
INSERT INTO `wp_posts` VALUES (6,1,'2025-07-19 21:00:58','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2025-07-19 21:00:58','0000-00-00 00:00:00','',0,'http://localhost/wordpress/?p=6',0,'post','',0);
INSERT INTO `wp_posts` VALUES (7,1,'2025-07-20 06:06:30','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','closed','','','','','2025-07-20 06:06:30','0000-00-00 00:00:00','',0,'http://localhost/wordpress/?post_type=property&p=7',0,'property','',0);
INSERT INTO `wp_posts` VALUES (9,1,'2025-07-20 07:47:57','2025-07-20 07:47:57','','Apart_1','','inherit','open','closed','','apart_1','','','2025-07-20 07:47:57','2025-07-20 07:47:57','',0,'http://localhost/wordpress/wp-content/uploads/2025/07/Apart_1.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (10,1,'2025-07-20 07:48:06','2025-07-20 07:48:06','','Apart_2','','inherit','open','closed','','apart_2','','','2025-07-20 07:48:06','2025-07-20 07:48:06','',0,'http://localhost/wordpress/wp-content/uploads/2025/07/Apart_2.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (11,1,'2025-07-20 08:29:25','2025-07-20 08:29:25','<!-- wp:paragraph -->\n<p>"I had an amazing experience working with JoyWSI. They helped me find my dream home in no time! The team was professional, knowledgeable, and always available to answer my questions. I highly recommend them to anyone looking to buy or sell a property!"</p>\n<!-- /wp:paragraph -->','Jayanto Choudhury','','publish','closed','closed','','jayanto-choudhury','','','2025-07-20 08:29:25','2025-07-20 08:29:25','',0,'http://localhost/wordpress/?post_type=testimonial&#038;p=11',0,'testimonial','',0);
INSERT INTO `wp_posts` VALUES (12,1,'2025-07-20 08:29:00','2025-07-20 08:29:00','','3','','inherit','open','closed','','3','','','2025-07-20 08:29:00','2025-07-20 08:29:00','',11,'http://localhost/wordpress/wp-content/uploads/2025/07/3.png',0,'attachment','image/png',0);
INSERT INTO `wp_posts` VALUES (13,1,'2025-07-20 09:39:32','2025-07-20 09:39:32','<!-- wp:paragraph -->\n<p>"Selling my house was a breeze thanks to JoyWSI. They provided excellent marketing strategies and kept me informed throughout the entire process. I was able to sell my home above the asking price! Thank you for your hard work!"</p>\n<!-- /wp:paragraph -->','Joy Kumar','','publish','closed','closed','','joy-kumar','','','2025-07-20 09:39:33','2025-07-20 09:39:33','',0,'http://localhost/wordpress/?post_type=testimonial&#038;p=13',0,'testimonial','',0);
INSERT INTO `wp_posts` VALUES (14,1,'2025-07-20 09:39:13','2025-07-20 09:39:13','','istockphoto-1165538334-2048x2048','Close-up portrait of his he nice attractive discontent guilty bearded guy isolated, over bright vivid shine violet lilac purple background','inherit','open','closed','','istockphoto-1165538334-2048x2048','','','2025-07-20 09:39:13','2025-07-20 09:39:13','',13,'http://localhost/wordpress/wp-content/uploads/2025/07/istockphoto-1165538334-2048x2048-1.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (15,1,'2025-07-20 13:57:21','2025-07-20 13:57:21','<!-- wp:paragraph -->\r\n<p><strong data-start="326" data-end="345">Crystal Heights</strong> is an ultra-modern residential project designed for comfort, sustainability, and premium living in the vibrant city of Pune. The property features contemporary architecture, open balconies, and a peaceful environment—perfect for first-time home buyers and young families.</p>\r\n<h3 data-start="624" data-end="656"><strong data-start="628" data-end="656">🏷️ Property Highlights:</strong></h3>\r\n<ul>\r\n<li data-start="657" data-end="703">\r\n<p data-start="659" data-end="703">Contemporary design with large balcony views</p>\r\n</li>\r\n<li data-start="704" data-end="757">\r\n<p data-start="706" data-end="757">Prime location near IT parks and metro connectivity</p>\r\n</li>\r\n<li data-start="758" data-end="808">\r\n<p data-start="760" data-end="808">Eco-friendly community with rainwater harvesting</p>\r\n</li>\r\n<li data-start="809" data-end="856">\r\n<p data-start="811" data-end="856">Gymnasium, clubhouse, and indoor gaming zones</p>\r\n</li>\r\n<li data-start="859" data-end="914">24/7 security, CCTV surveillance, and dedicated parkin</li>\r\n</ul>\r\n<h3 data-start="921" data-end="949"><strong data-start="925" data-end="949">📋 Property Details:</strong></h3>\r\n<ul data-start="950" data-end="1237">\r\n<li data-start="950" data-end="971">\r\n<p data-start="952" data-end="971">🛏️ <strong data-start="956" data-end="969">Bedrooms:</strong> 5</p>\r\n</li>\r\n<li data-start="972" data-end="993">\r\n<p data-start="974" data-end="993">🛁 <strong data-start="977" data-end="991">Bathrooms:</strong> 2</p>\r\n</li>\r\n<li data-start="994" data-end="1022">\r\n<p data-start="996" data-end="1022">📐 <strong data-start="999" data-end="1008">Area:</strong> 1,180 sq. ft.</p>\r\n</li>\r\n<li data-start="1052" data-end="1093">\r\n<p data-start="1054" data-end="1093">🏗️ <strong data-start="1058" data-end="1076">Property Type:</strong> House</p>\r\n</li>\r\n<li data-start="1094" data-end="1141">\r\n<p data-start="1096" data-end="1141">📍 <strong data-start="1099" data-end="1112">Location:</strong> Dhanbad, Jharkhand</p>\r\n</li>\r\n<li data-start="1142" data-end="1175">\r\n<p data-start="1144" data-end="1175">💰 <strong data-start="1147" data-end="1157">Price:</strong> ₹32 Lakhs Onwards</p>\r\n</li>\r\n<li data-start="1176" data-end="1237">\r\n<p data-start="1178" data-end="1237">🚧 <strong data-start="1181" data-end="1192">Status:</strong> Ready To Move</p>\r\n</li>\r\n</ul>\r\n<!-- /wp:paragraph -->','Dhanbad Loft Apartment','','publish','open','open','','dhanbad-loft-apartment','','','2025-07-25 07:16:33','2025-07-25 07:16:33','',0,'http://localhost/wordpress/?post_type=property&#038;p=15',0,'property','',0);
INSERT INTO `wp_posts` VALUES (16,1,'2025-07-20 13:56:56','2025-07-20 13:56:56','','Apart_4','','inherit','open','closed','','apart_4','','','2025-07-20 13:56:56','2025-07-20 13:56:56','',15,'http://localhost/wordpress/wp-content/uploads/2025/07/Apart_4.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (17,1,'2025-07-20 14:11:50','2025-07-20 14:11:50','<!-- wp:paragraph -->\r\n<p>Skyline Residency is a premium residential apartment located in the heart of the city, offering a blend of luxury, comfort, and modern architecture. With a beautifully designed facade and spacious interiors, this property is perfect for families and working professionals seeking urban convenience and elegant living.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Property Highlights:</strong></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul class="wp-block-list"><!-- wp:list-item -->\r\n<li>Modern architecture with clean white exterior</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>Prime city location with easy access to schools, shopping, and hospitals</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>24x7 security &amp; power backup</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>Basement parking and landscaped surroundings</li>\r\n<!-- /wp:list-item --></ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Property Details:</strong></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul class="wp-block-list"><!-- wp:list-item -->\r\n<li>🛏️ <strong>Bedrooms:</strong> 3</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🛁 <strong>Bathrooms:</strong> 2</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>📐 <strong>Area:</strong> 1,450 sq. ft.</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🏢 <strong>Floors:</strong> Ground + 4</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🏗️ <strong>Property Type:</strong> Apartment / Flat</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>📍 <strong>Location:</strong> Bengaluru, Karnataka</li>\r\n<!-- /wp:list-item --></ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Price:</strong> ₹98 Lakhs Onwards<br /><strong>Status:</strong> Ready to Move In</p>\r\n<!-- /wp:paragraph -->','Skyline Residency','','publish','open','open','','skyline-residency','','','2025-07-25 07:16:15','2025-07-25 07:16:15','',0,'http://localhost/wordpress/?post_type=property&#038;p=17',0,'property','',0);
INSERT INTO `wp_posts` VALUES (18,1,'2025-07-20 14:11:39','2025-07-20 14:11:39','','pexels-bluerhinomedia-3663530','','inherit','open','closed','','pexels-bluerhinomedia-3663530','','','2025-07-20 14:11:39','2025-07-20 14:11:39','',17,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-bluerhinomedia-3663530.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (19,1,'2025-07-20 14:14:06','2025-07-20 14:14:06','','pexels-bluerhinomedia-3663530','','inherit','open','closed','','pexels-bluerhinomedia-3663530-2','','','2025-07-20 14:14:06','2025-07-20 14:14:06','',17,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-bluerhinomedia-3663530-1.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (20,1,'2025-07-20 14:20:49','2025-07-20 14:20:49','<!-- wp:paragraph -->\r\n<p>Rainbow Heritage Villas is a vibrant residential enclave offering uniquely styled, independent villa apartments. Inspired by European architecture and nestled in a peaceful, green environment, these homes blend artistic design with practical urban living. Ideal for families who seek charm and community spirit with modern amenities.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Property Highlights:</strong></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul class="wp-block-list"><!-- wp:list-item -->\r\n<li>🎨 Distinct colorful facades with sloped tile roofs</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🪟 Premium wood-framed windows with traditional shutters</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🌳 Lush landscaped gardens &amp; outdoor seating areas</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🛣️ Located in a gated community with internal paved roads</li>\r\n<!-- /wp:list-item --></ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Property Details:</strong></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul class="wp-block-list"><!-- wp:list-item -->\r\n<li>🛏️ <strong>Bedrooms:</strong> 4</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🛁 <strong>Bathrooms:</strong> 3</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>📐 <strong>Area:</strong> 2,200 sq. ft.</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🏠 <strong>Floors:</strong> Ground + 2</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🏡 <strong>Property Type:</strong> Villa Apartment</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>📍 <strong>Location:</strong> Lonavala, Maharashtra</li>\r\n<!-- /wp:list-item --></ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Price:</strong> ₹1.65 Crores Onwards<br /><strong>Status:</strong> Under Construction (Possession by Dec 2025)</p>\r\n<!-- /wp:paragraph -->','Rainbow Heritage Villas','','publish','open','open','','rainbow-heritage-villas','','','2025-07-25 07:15:33','2025-07-25 07:15:33','',0,'http://localhost/wordpress/?post_type=property&#038;p=20',0,'property','',0);
INSERT INTO `wp_posts` VALUES (21,1,'2025-07-20 14:20:19','2025-07-20 14:20:19','','pexels-pixabay-415687','','inherit','open','closed','','pexels-pixabay-415687','','','2025-07-20 14:20:19','2025-07-20 14:20:19','',20,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-pixabay-415687.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (22,1,'2025-07-20 14:26:14','2025-07-20 14:26:14','<!-- wp:paragraph -->\r\n<p>Royale Arc Residences offers timeless European grandeur with modern-day luxury. Inspired by classic Parisian architecture, this premium apartment complex blends old-world charm with contemporary amenities. Each residence is adorned with intricate façade details, wrought-iron balconies, and expansive interiors — a perfect fusion of class and comfort in the heart of the city.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Property Highlights:</strong></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul class="wp-block-list"><!-- wp:list-item -->\r\n<li>🏛️ Heritage-style elevation with stone-finished façade</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🖼️ Decorative balconies &amp; French-style windows</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🛎️ Concierge service, valet parking &amp; private elevators</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🌆 Located in a prestigious neighborhood with cultural landmarks</li>\r\n<!-- /wp:list-item --></ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Property Details:</strong></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul class="wp-block-list"><!-- wp:list-item -->\r\n<li>🛏️ <strong>Bedrooms:</strong> 5</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🛁 <strong>Bathrooms:</strong> 4</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>📐 <strong>Area:</strong> 3,800 sq. ft.</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🏢 <strong>Floors:</strong> Ground + 6</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🏠 <strong>Property Type:</strong> Luxury Apartment</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>📍 <strong>Location:</strong> Altamount Road, Mumbai</li>\r\n<!-- /wp:list-item --></ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Price:</strong> ₹8.5 Crores Onwards<br /><strong>Status:</strong> Ready to Move In</p>\r\n<!-- /wp:paragraph -->','Royale Arc Residences','','publish','open','open','','royale-arc-residences','','','2025-07-25 07:10:42','2025-07-25 07:10:42','',0,'http://localhost/wordpress/?post_type=property&#038;p=22',0,'property','',0);
INSERT INTO `wp_posts` VALUES (23,1,'2025-07-20 14:26:09','2025-07-20 14:26:09','','pexels-myatezhny39-2422433','','inherit','open','closed','','pexels-myatezhny39-2422433','','','2025-07-20 14:26:09','2025-07-20 14:26:09','',22,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-myatezhny39-2422433.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (24,1,'2025-07-20 14:31:49','2025-07-20 14:31:49','<!-- wp:paragraph -->\r\n<p>Greenview House Estate offers serene living in a lush, green environment. This independent home is ideal for families looking to escape city congestion without sacrificing comfort. The house features classic architecture, a manicured front lawn, and spacious interiors for luxurious one-level living.</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Property Highlights:</strong></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul class="wp-block-list"><!-- wp:list-item -->\r\n<li>🌳 Expansive front yard and garden space</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🏠 Single-story house design for easy living</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🚗 Private driveway and covered parking</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🧘 Calm, pollution-free environment — perfect for retirement or family life</li>\r\n<!-- /wp:list-item --></ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Property Details:</strong></p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:list -->\r\n<ul class="wp-block-list"><!-- wp:list-item -->\r\n<li>🛏️ <strong>Bedrooms:</strong> 6</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🛁 <strong>Bathrooms:</strong> 2</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>📐 <strong>Area:</strong> 2,750 sq. ft.</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>🏠 <strong>Property Type:</strong> Independent House</li>\r\n<!-- /wp:list-item -->\r\n\r\n<!-- wp:list-item -->\r\n<li>📍 <strong>Location:</strong> Dhanbad, Jharkhand</li>\r\n<!-- /wp:list-item --></ul>\r\n<!-- /wp:list -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong>Price:</strong> ₹43 Lakhs<br /><strong>Status:</strong> Ready to Move In</p>\r\n<!-- /wp:paragraph -->','Greenview House Estate','','publish','open','open','','greenview-house-estate','','','2025-07-25 07:10:21','2025-07-25 07:10:21','',0,'http://localhost/wordpress/?post_type=property&#038;p=24',0,'property','',0);
INSERT INTO `wp_posts` VALUES (25,1,'2025-07-21 18:51:03','2025-07-20 15:46:52','','Home','','publish','closed','closed','','home','','','2025-07-21 18:51:03','2025-07-21 18:51:03','',0,'http://localhost/wordpress/?p=25',1,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (26,1,'2025-07-21 18:51:03','2025-07-20 15:46:52',' ','','','publish','closed','closed','','26','','','2025-07-21 18:51:03','2025-07-21 18:51:03','',0,'http://localhost/wordpress/?p=26',2,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (27,1,'2025-07-20 15:47:14','2025-07-20 15:47:14','','Home','','publish','closed','closed','','home','','','2025-07-20 15:47:14','2025-07-20 15:47:14','',0,'http://localhost/wordpress/?page_id=27',0,'page','',0);
INSERT INTO `wp_posts` VALUES (28,1,'2025-07-20 15:47:14','2025-07-20 15:47:14','','Home','','inherit','closed','closed','','27-revision-v1','','','2025-07-20 15:47:14','2025-07-20 15:47:14','',27,'http://localhost/wordpress/?p=28',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (29,1,'2025-07-20 15:47:34','2025-07-20 15:47:34','','About Us','','publish','closed','closed','','about-us','','','2025-07-20 15:47:34','2025-07-20 15:47:34','',0,'http://localhost/wordpress/?page_id=29',0,'page','',0);
INSERT INTO `wp_posts` VALUES (30,1,'2025-07-20 15:47:34','2025-07-20 15:47:34','','About Us','','inherit','closed','closed','','29-revision-v1','','','2025-07-20 15:47:34','2025-07-20 15:47:34','',29,'http://localhost/wordpress/?p=30',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (31,1,'2025-07-20 15:47:49','2025-07-20 15:47:49','','Contact Us','','publish','closed','closed','','contact-us','','','2025-07-20 15:47:49','2025-07-20 15:47:49','',0,'http://localhost/wordpress/?page_id=31',0,'page','',0);
INSERT INTO `wp_posts` VALUES (32,1,'2025-07-20 15:47:49','2025-07-20 15:47:49','','Contact Us','','inherit','closed','closed','','31-revision-v1','','','2025-07-20 15:47:49','2025-07-20 15:47:49','',31,'http://localhost/wordpress/?p=32',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (33,1,'2025-07-21 18:51:03','2025-07-20 15:48:12',' ','','','publish','closed','closed','','33','','','2025-07-21 18:51:03','2025-07-21 18:51:03','',0,'http://localhost/wordpress/?p=33',3,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (34,1,'2025-07-21 18:51:03','2025-07-20 15:48:12',' ','','','publish','closed','closed','','34','','','2025-07-21 18:51:03','2025-07-21 18:51:03','',0,'http://localhost/wordpress/?p=34',4,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (35,1,'2025-07-21 18:51:03','2025-07-20 15:48:12',' ','','','publish','closed','closed','','35','','','2025-07-21 18:51:03','2025-07-21 18:51:03','',0,'http://localhost/wordpress/?p=35',5,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (36,1,'2025-07-20 16:02:51','0000-00-00 00:00:00','','Auto Draft','','auto-draft','closed','closed','','','','','2025-07-20 16:02:51','0000-00-00 00:00:00','',0,'http://localhost/wordpress/?post_type=property&p=36',0,'property','',0);
INSERT INTO `wp_posts` VALUES (37,1,'2025-07-20 16:22:58','0000-00-00 00:00:00','','Auto Draft','','auto-draft','closed','closed','','','','','2025-07-20 16:22:58','0000-00-00 00:00:00','',0,'http://localhost/wordpress/?post_type=property&p=37',0,'property','',0);
INSERT INTO `wp_posts` VALUES (38,1,'2025-07-20 20:36:21','2025-07-20 20:36:21','','pexels-atomlaborblog-1105754','','inherit','open','closed','','pexels-atomlaborblog-1105754','','','2025-07-20 20:36:21','2025-07-20 20:36:21','',24,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-atomlaborblog-1105754.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (39,1,'2025-07-20 20:40:05','2025-07-20 20:40:05','','pexels-pixabay-210617','','inherit','open','closed','','pexels-pixabay-210617','','','2025-07-20 20:40:05','2025-07-20 20:40:05','',15,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-pixabay-210617.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (40,1,'2025-07-20 20:42:43','2025-07-20 20:42:43','<!-- wp:paragraph -->\n<p><strong data-start="326" data-end="345">Crystal Heights</strong> is an ultra-modern residential project designed for comfort, sustainability, and premium living in the vibrant city of Pune. The property features contemporary architecture, open balconies, and a peaceful environment—perfect for first-time home buyers and young families.</p>\n<h3 data-start="624" data-end="656"><strong data-start="628" data-end="656">🏷️ Property Highlights:</strong></h3>\n<ul data-start="657" data-end="914">\n<li data-start="657" data-end="703">\n<p data-start="659" data-end="703">Contemporary design with large balcony views</p>\n</li>\n<li data-start="704" data-end="757">\n<p data-start="706" data-end="757">Prime location near IT parks and metro connectivity</p>\n</li>\n<li data-start="758" data-end="808">\n<p data-start="760" data-end="808">Eco-friendly community with rainwater harvesting</p>\n</li>\n<li data-start="809" data-end="856">\n<p data-start="811" data-end="856">Gymnasium, clubhouse, and indoor gaming zones</p>\n</li>\n<li data-start="857" data-end="914">\n<p data-start="859" data-end="914">24/7 security, CCTV surveillance, and dedicated parking</p>\n</li>\n</ul>\n<!-- /wp:paragraph -->','Dhanbad Loft Apartment','','inherit','closed','closed','','15-autosave-v1','','','2025-07-20 20:42:43','2025-07-20 20:42:43','',15,'http://localhost/wordpress/?p=40',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (41,1,'2025-07-21 06:53:34','2025-07-21 06:53:34','Palm Grove Villa offers a stunning combination of <strong data-start="258" data-end="275">luxury living</strong>, <strong data-start="277" data-end="303">resort-style amenities</strong>, and <strong data-start="309" data-end="332">serene surroundings</strong> in the most desirable area of <strong data-start="363" data-end="376">North Goa</strong>. Surrounded by lush palm trees and featuring a private crystal-clear swimming pool, this property is the <strong data-start="482" data-end="501">perfect getaway</strong> for families, celebrities, and business professionals looking for exclusivity.\r\n<h3 data-start="587" data-end="619">🏷️ <strong data-start="595" data-end="619">Property Highlights:</strong></h3>\r\n<ul data-start="620" data-end="928">\r\n 	<li data-start="620" data-end="674">\r\n<p data-start="622" data-end="674">Spacious luxury villa with <strong data-start="649" data-end="674">private swimming pool</strong></p>\r\n</li>\r\n 	<li data-start="675" data-end="741">\r\n<p data-start="677" data-end="741"><strong data-start="677" data-end="741">Fully furnished with premium interiors and modern appliances</strong></p>\r\n</li>\r\n 	<li data-start="742" data-end="792">\r\n<p data-start="744" data-end="792">Landscaped garden and <strong data-start="766" data-end="792">outdoor lounge seating</strong></p>\r\n</li>\r\n 	<li data-start="793" data-end="841">\r\n<p data-start="795" data-end="841"><strong data-start="795" data-end="819">Poolside dining area</strong> with open bar counter</p>\r\n</li>\r\n 	<li data-start="842" data-end="890">\r\n<p data-start="844" data-end="890">24×7 security with <strong data-start="863" data-end="890">smart CCTV surveillance</strong></p>\r\n</li>\r\n 	<li data-start="891" data-end="928">\r\n<p data-start="893" data-end="928">Ample parking with private driveway</p>\r\n</li>\r\n</ul>\r\n<h3 data-start="935" data-end="963">📋 <strong data-start="942" data-end="963">Property Details:</strong></h3>\r\n<ul data-start="964" data-end="1174">\r\n 	<li data-start="964" data-end="985">\r\n<p data-start="966" data-end="985">🛏️ <strong data-start="970" data-end="983">Bedrooms:</strong> 5</p>\r\n</li>\r\n 	<li data-start="986" data-end="1007">\r\n<p data-start="988" data-end="1007">🛁 <strong data-start="991" data-end="1005">Bathrooms:</strong> 2</p>\r\n</li>\r\n 	<li data-start="986" data-end="1007"><strong>Swimming Pool</strong></li>\r\n 	<li data-start="1008" data-end="1036">\r\n<p data-start="1010" data-end="1036">📐 <strong data-start="1013" data-end="1022">Area:</strong> 3,800 sq. ft.</p>\r\n</li>\r\n 	<li data-start="1037" data-end="1067">\r\n<p data-start="1039" data-end="1067">🏗️ <strong data-start="1043" data-end="1061">Property Type:</strong> Villa</p>\r\n</li>\r\n 	<li data-start="1068" data-end="1104">\r\n<p data-start="1070" data-end="1104">📍 <strong data-start="1073" data-end="1086">Location:</strong> Anjuna, North Goa</p>\r\n</li>\r\n 	<li data-start="1105" data-end="1140">\r\n<p data-start="1107" data-end="1140">💰 <strong data-start="1110" data-end="1120">Price:</strong> ₹1.9 Crores Onwards</p>\r\n</li>\r\n 	<li data-start="1141" data-end="1174">\r\n<p data-start="1143" data-end="1174">🚧 <strong data-start="1146" data-end="1157">Status:</strong> Ready to Move-In</p>\r\n</li>\r\n</ul>','Private Escape Villa','','publish','closed','closed','','a-luxurious-private-escape-in-goa','','','2025-07-25 07:09:47','2025-07-25 07:09:47','',0,'http://localhost/wordpress/?post_type=property&#038;p=41',0,'property','',0);
INSERT INTO `wp_posts` VALUES (42,1,'2025-07-21 06:53:19','2025-07-21 06:53:19','','pexels-william-lemond-25283-105933','','inherit','open','closed','','pexels-william-lemond-25283-105933','','','2025-07-21 06:53:19','2025-07-21 06:53:19','',41,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-william-lemond-25283-105933.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (43,1,'2025-07-21 06:57:49','2025-07-21 06:57:49','Experience peaceful countryside charm blended with <strong data-start="289" data-end="312">modern architecture</strong> at Maplewood Estate, a gorgeous <strong data-start="345" data-end="365">standalone house</strong> situated in the lush green foothills of <strong data-start="406" data-end="418">Dehradun</strong>. With expansive lawns, open-air seating, and cozy interiors, this property offers the <strong data-start="505" data-end="540">perfect escape from urban chaos</strong> while keeping you connected to city essentials.\r\n<h3 data-start="595" data-end="627">🏷️ <strong data-start="603" data-end="627">Property Highlights:</strong></h3>\r\n<ul data-start="628" data-end="966">\r\n 	<li data-start="628" data-end="680">\r\n<p data-start="630" data-end="680">Elegant <strong data-start="638" data-end="680">double-story home with sloped rooftops</strong></p>\r\n</li>\r\n 	<li data-start="681" data-end="738">\r\n<p data-start="683" data-end="738"><strong data-start="683" data-end="708">Spacious private lawn</strong> ideal for gatherings and play</p>\r\n</li>\r\n 	<li data-start="739" data-end="801">\r\n<p data-start="741" data-end="801"><strong data-start="741" data-end="759">Modern kitchen</strong> with modular fittings and attached pantry</p>\r\n</li>\r\n 	<li data-start="802" data-end="868">\r\n<p data-start="804" data-end="868"><strong data-start="804" data-end="843">Natural light-friendly architecture</strong> with large glass windows</p>\r\n</li>\r\n 	<li data-start="869" data-end="913">\r\n<p data-start="871" data-end="913">Covered car parking &amp; <strong data-start="893" data-end="913">outdoor BBQ deck</strong></p>\r\n</li>\r\n 	<li data-start="914" data-end="966">\r\n<p data-start="916" data-end="966"><strong data-start="916" data-end="943">Secured gated community</strong> with 24×7 surveillance</p>\r\n</li>\r\n</ul>\r\n<h3 data-start="973" data-end="1001">📋 <strong data-start="980" data-end="1001">Property Details:</strong></h3>\r\n<ul data-start="1002" data-end="1236">\r\n 	<li data-start="1002" data-end="1023">\r\n<p data-start="1004" data-end="1023">🛏️ <strong data-start="1008" data-end="1021">Bedrooms:</strong> 5</p>\r\n</li>\r\n 	<li data-start="1024" data-end="1045">\r\n<p data-start="1026" data-end="1045">🛁 <strong data-start="1029" data-end="1043">Bathrooms:</strong> 2</p>\r\n</li>\r\n 	<li data-start="1046" data-end="1074">\r\n<p data-start="1048" data-end="1074">📐 <strong data-start="1051" data-end="1060">Area:</strong> 1,800 sq. ft.</p>\r\n</li>\r\n 	<li data-start="1075" data-end="1105">\r\n<p data-start="1077" data-end="1105">🏗️ <strong data-start="1081" data-end="1099">Property Type:</strong> House</p>\r\n</li>\r\n 	<li data-start="1106" data-end="1166">\r\n<p data-start="1108" data-end="1166">📍 <strong data-start="1111" data-end="1124">Location:</strong> Sahastradhara Road, Dehradun, Uttarakhand</p>\r\n</li>\r\n 	<li data-start="1167" data-end="1202">\r\n<p data-start="1169" data-end="1202">💰 <strong data-start="1172" data-end="1182">Price:</strong> ₹1.4 Crores Onwards</p>\r\n</li>\r\n 	<li data-start="1203" data-end="1236">\r\n<p data-start="1205" data-end="1236">🚧 <strong data-start="1208" data-end="1219">Status:</strong> Ready to Move-In</p>\r\n</li>\r\n</ul>','Maplewood Countryside Living','','publish','closed','closed','','maplewood-elegant-countryside-living','','','2025-07-25 07:09:19','2025-07-25 07:09:19','',0,'http://localhost/wordpress/?post_type=property&#038;p=43',0,'property','',0);
INSERT INTO `wp_posts` VALUES (44,1,'2025-07-21 06:57:45','2025-07-21 06:57:45','','Apart9','','inherit','open','closed','','apart9','','','2025-07-21 06:57:45','2025-07-21 06:57:45','',43,'http://localhost/wordpress/wp-content/uploads/2025/07/Apart9.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (45,1,'2025-07-21 07:06:37','2025-07-21 07:06:37','Discover timeless elegance with <strong data-start="258" data-end="277">Stonehill House</strong>, a beautifully crafted <strong data-start="301" data-end="317">luxury house</strong> nestled in the tranquil lanes of <strong data-start="351" data-end="363">Lonavala</strong>. With rustic stone architecture, manicured green lawns, and ample outdoor space, it’s a perfect getaway for families and holiday home seekers.\r\n<h3 data-start="513" data-end="545">🏷️ <strong data-start="521" data-end="545">Property Highlights:</strong></h3>\r\n<ul data-start="546" data-end="856">\r\n 	<li data-start="546" data-end="601">\r\n<p data-start="548" data-end="601"><strong data-start="548" data-end="579">Vintage stone-crafted house</strong> with modern interiors</p>\r\n</li>\r\n 	<li data-start="602" data-end="652">\r\n<p data-start="604" data-end="652"><strong data-start="604" data-end="630">Lush landscaped garden</strong> with private driveway</p>\r\n</li>\r\n 	<li data-start="653" data-end="699">\r\n<p data-start="655" data-end="699"><strong data-start="655" data-end="673">Spacious porch</strong> and outdoor sitting areas</p>\r\n</li>\r\n 	<li data-start="700" data-end="759">\r\n<p data-start="702" data-end="759">Fully <strong data-start="708" data-end="727">modular kitchen</strong> and <strong data-start="732" data-end="759">premium wooden flooring</strong></p>\r\n</li>\r\n 	<li data-start="760" data-end="809">\r\n<p data-start="762" data-end="809"><strong data-start="762" data-end="809">Dedicated servant quarters &amp; covered garage</strong></p>\r\n</li>\r\n</ul>\r\n<h3 data-start="863" data-end="891">📋 <strong data-start="870" data-end="891">Property Details:</strong></h3>\r\n<ul data-start="892" data-end="1121">\r\n 	<li data-start="892" data-end="913">\r\n<p data-start="894" data-end="913">🛏️ <strong data-start="898" data-end="911">Bedrooms:</strong> 4</p>\r\n</li>\r\n 	<li data-start="914" data-end="935">\r\n<p data-start="916" data-end="935">🛁 <strong data-start="919" data-end="933">Bathrooms:</strong> 1</p>\r\n</li>\r\n 	<li data-start="936" data-end="964">\r\n<p data-start="938" data-end="964">📐 <strong data-start="941" data-end="950">Area:</strong> 600 sq. ft.</p>\r\n</li>\r\n 	<li data-start="965" data-end="995">\r\n<p data-start="967" data-end="995">🏗️ <strong data-start="971" data-end="989">Property Type:</strong> Villa</p>\r\n</li>\r\n 	<li data-start="996" data-end="1046">\r\n<p data-start="998" data-end="1046">📍 <strong data-start="1001" data-end="1014">Location:</strong> Khandala, Lonavala, Maharashtra</p>\r\n</li>\r\n 	<li data-start="1047" data-end="1083">\r\n<p data-start="1049" data-end="1083">💰 <strong data-start="1052" data-end="1062">Price:</strong> ₹39 Lakhs Onwards</p>\r\n</li>\r\n 	<li data-start="1084" data-end="1121">\r\n<p data-start="1086" data-end="1121">🚧 <strong data-start="1089" data-end="1100">Status:</strong> Ready for Possession</p>\r\n</li>\r\n</ul>','Stonehill Heart Living','','publish','closed','closed','','stonehill-house-premium-luxury-living','','','2025-07-25 07:08:56','2025-07-25 07:08:56','',0,'http://localhost/wordpress/?post_type=property&#038;p=45',0,'property','',0);
INSERT INTO `wp_posts` VALUES (46,1,'2025-07-21 07:06:15','2025-07-21 07:06:15','','Aprt10','','inherit','open','closed','','aprt10','','','2025-07-21 07:06:15','2025-07-21 07:06:15','',45,'http://localhost/wordpress/wp-content/uploads/2025/07/Aprt10.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (47,1,'2025-07-21 15:26:56','0000-00-00 00:00:00','','Auto Draft','','auto-draft','closed','closed','','','','','2025-07-21 15:26:56','0000-00-00 00:00:00','',0,'http://localhost/wordpress/?post_type=property&p=47',0,'property','',0);
INSERT INTO `wp_posts` VALUES (48,1,'2025-07-21 19:17:54','2025-07-21 19:17:54','Experience the epitome of royal comfort at <strong data-start="286" data-end="310">Oakridge Royal Villa</strong>, a sprawling luxury villa located in the serene outskirts of <strong data-start="372" data-end="385">Hyderabad</strong>. This property offers timeless European-style architecture, high ceilings, and vast open spaces — perfect for those who desire both luxury and privacy.\r\n<h3 data-start="544" data-end="576">🏷️ <strong data-start="552" data-end="576">Property Highlights:</strong></h3>\r\n<ul data-start="577" data-end="889">\r\n 	<li data-start="577" data-end="635">\r\n<p data-start="579" data-end="635"><strong data-start="579" data-end="617">Majestic brick and stone elevation</strong> with royal appeal</p>\r\n</li>\r\n 	<li data-start="636" data-end="685">\r\n<p data-start="638" data-end="685"><strong data-start="638" data-end="663">Large manicured lawns</strong> with stone staircases</p>\r\n</li>\r\n 	<li data-start="686" data-end="730">\r\n<p data-start="688" data-end="730"><strong data-start="688" data-end="730">Double-height ceilings and bay windows</strong></p>\r\n</li>\r\n 	<li data-start="731" data-end="781">\r\n<p data-start="733" data-end="781"><strong data-start="733" data-end="759">Spacious covered porch</strong> for family gatherings</p>\r\n</li>\r\n 	<li data-start="782" data-end="837">\r\n<p data-start="784" data-end="837"><strong data-start="784" data-end="837">Premium wooden interiors and modern kitchen setup</strong></p>\r\n</li>\r\n 	<li data-start="838" data-end="889">\r\n<p data-start="840" data-end="889"><strong data-start="840" data-end="859">Gated community</strong> with round-the-clock security</p>\r\n</li>\r\n</ul>\r\n<h3 data-start="896" data-end="924">📋 <strong data-start="903" data-end="924">Property Details:</strong></h3>\r\n<ul data-start="925" data-end="1177">\r\n 	<li data-start="925" data-end="946">\r\n<p data-start="927" data-end="946">🛏️ <strong data-start="931" data-end="944">Bedrooms:</strong> 7</p>\r\n</li>\r\n 	<li data-start="947" data-end="968">\r\n<p data-start="949" data-end="968">🛁 <strong data-start="952" data-end="966">Bathrooms:</strong> 2</p>\r\n</li>\r\n 	<li data-start="969" data-end="997">\r\n<p data-start="971" data-end="997">📐 <strong data-start="974" data-end="983">Area:</strong> 2700 sq. ft.</p>\r\n</li>\r\n 	<li data-start="998" data-end="1028">\r\n<p data-start="1000" data-end="1028">🏗️ <strong data-start="1004" data-end="1022">Property Type:</strong> Villa</p>\r\n</li>\r\n 	<li data-start="1029" data-end="1080">\r\n<p data-start="1031" data-end="1080">📍 <strong data-start="1034" data-end="1047">Location:</strong> Gachibowli, Hyderabad, Telangana</p>\r\n</li>\r\n 	<li data-start="1081" data-end="1116">\r\n<p data-start="1083" data-end="1116">💰 <strong data-start="1086" data-end="1096">Price:</strong> ₹3.7 Crores Onwards</p>\r\n</li>\r\n 	<li data-start="1117" data-end="1177">\r\n<p data-start="1119" data-end="1177">🚧 <strong data-start="1122" data-end="1133">Status:</strong> Under Construction (Possession in 6 Months)</p>\r\n</li>\r\n</ul>','Oakridge Royal Villa','','publish','closed','closed','','oakridge-royal-villa','','','2025-07-25 07:06:21','2025-07-25 07:06:21','',0,'http://localhost/wordpress/?post_type=property&#038;p=48',0,'property','',0);
INSERT INTO `wp_posts` VALUES (49,1,'2025-07-21 19:17:45','2025-07-21 19:17:45','','name','','inherit','open','closed','','name','','','2025-07-21 19:17:45','2025-07-21 19:17:45','',48,'http://localhost/wordpress/wp-content/uploads/2025/07/name.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (50,1,'2025-07-22 17:58:00','2025-07-22 17:58:00','<p data-start="97" data-end="518"><strong data-start="97" data-end="118">Rosewood Grandeur</strong> is a majestic villa offering a blend of traditional charm and modern luxury. Nestled amidst lush greenery with extensive private land surrounding the property, this villa is perfect for those seeking peaceful countryside living with premium amenities. The striking red brick exterior, classic architectural details, and spacious interiors make this property a true statement of elegance and comfort.</p>\r\n<p data-start="520" data-end="548">🏷️ <strong data-start="524" data-end="548">Property Highlights:</strong></p>\r\n\r\n<ul data-start="549" data-end="797">\r\n 	<li data-start="549" data-end="603">\r\n<p data-start="551" data-end="603">Elegant traditional design with sloped tiled roofing</p>\r\n</li>\r\n 	<li data-start="604" data-end="656">\r\n<p data-start="606" data-end="656">Includes vast outdoor private land and garden area</p>\r\n</li>\r\n 	<li data-start="657" data-end="703">\r\n<p data-start="659" data-end="703">Ample natural light with large panel windows</p>\r\n</li>\r\n 	<li data-start="704" data-end="747">\r\n<p data-start="706" data-end="747">Premium locality with scenic surroundings</p>\r\n</li>\r\n 	<li data-start="748" data-end="797">\r\n<p data-start="750" data-end="797">Ideal for family getaways or countryside living</p>\r\n</li>\r\n</ul>\r\n<p data-start="799" data-end="823">📋 <strong data-start="802" data-end="823">Property Details:</strong></p>\r\n\r\n<ul data-start="824" data-end="1107">\r\n 	<li data-start="824" data-end="845">\r\n<p data-start="826" data-end="845">🛏️ <strong data-start="830" data-end="843">Bedrooms:</strong> 12</p>\r\n</li>\r\n 	<li data-start="846" data-end="867">\r\n<p data-start="848" data-end="867">🛁 <strong data-start="851" data-end="865">Bathrooms:</strong> 4</p>\r\n</li>\r\n 	<li data-start="868" data-end="907">\r\n<p data-start="870" data-end="907">📐 <strong data-start="873" data-end="893">Area (Built-up):</strong> 3,800 sq. ft.</p>\r\n</li>\r\n 	<li data-start="908" data-end="967">\r\n<p data-start="910" data-end="967">🌳 <strong data-start="913" data-end="952">Total Land Area (including garden):</strong> 4,600 sq. ft.</p>\r\n</li>\r\n 	<li data-start="968" data-end="998">\r\n<p data-start="970" data-end="998">🏗️ <strong data-start="974" data-end="992">Property Type:</strong> Villa</p>\r\n</li>\r\n 	<li data-start="999" data-end="1037">\r\n<p data-start="1001" data-end="1037">📍 <strong data-start="1004" data-end="1017">Location:</strong> Kolkata</p>\r\n</li>\r\n 	<li data-start="1038" data-end="1073">\r\n<p data-start="1040" data-end="1073">💰 <strong data-start="1043" data-end="1053">Price:</strong> ₹3.4 Crores Onwards</p>\r\n</li>\r\n 	<li data-start="1074" data-end="1107">\r\n<p data-start="1076" data-end="1107">🚧 <strong data-start="1079" data-end="1090">Status:</strong> Ready to Move In</p>\r\n</li>\r\n</ul>','Rosewood Grandeur','','publish','closed','closed','','rosewood-grandeur','','','2025-07-25 07:05:42','2025-07-25 07:05:42','',0,'http://localhost/wordpress/?post_type=property&#038;p=50',0,'property','',0);
INSERT INTO `wp_posts` VALUES (51,1,'2025-07-22 17:57:55','2025-07-22 17:57:55','','pexels-fazza-36355','','inherit','open','closed','','pexels-fazza-36355','','','2025-07-22 17:57:55','2025-07-22 17:57:55','',50,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-fazza-36355.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (52,1,'2025-07-23 08:04:56','2025-07-23 08:04:56','','pexels-william-lemond-25283-105933','','inherit','open','closed','','pexels-william-lemond-25283-105933-2','','','2025-07-23 08:04:56','2025-07-23 08:04:56','',50,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-william-lemond-25283-105933.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (53,1,'2025-07-23 08:04:56','2025-07-23 08:04:56','','pexels-pixabay-210617','','inherit','open','closed','','pexels-pixabay-210617-2','','','2025-07-23 08:04:56','2025-07-23 08:04:56','',50,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-pixabay-210617.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (54,1,'2025-07-23 08:04:56','2025-07-23 08:04:56','','pexels-atomlaborblog-1105754','','inherit','open','closed','','pexels-atomlaborblog-1105754-2','','','2025-07-23 08:04:56','2025-07-23 08:04:56','',50,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-atomlaborblog-1105754.jpg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (55,1,'2025-07-23 16:45:13','2025-07-23 16:45:13','<strong data-start="83" data-end="105">Regal Crest Estate</strong> is an iconic palace-style residence, exuding timeless grandeur and architectural brilliance. With its magnificent dome, intricately carved arches, and expansive façade, this property stands as a symbol of luxury and legacy. Surrounded by manicured gardens and expansive grounds, it offers unmatched space and elegance, ideal for luxury living, heritage hospitality, or private retreats.\r\n<p data-start="494" data-end="522">🏷️ <strong data-start="498" data-end="522">Property Highlights:</strong></p>\r\n\r\n<ul data-start="524" data-end="812">\r\n 	<li data-start="524" data-end="582">\r\n<p data-start="526" data-end="582">Majestic dome with intricate neoclassical architecture</p>\r\n</li>\r\n 	<li data-start="583" data-end="645">\r\n<p data-start="585" data-end="645">Surrounded by vast landscaped gardens and open green space</p>\r\n</li>\r\n 	<li data-start="646" data-end="693">\r\n<p data-start="648" data-end="693">Grand arched windows and detailed stonework</p>\r\n</li>\r\n 	<li data-start="694" data-end="745">\r\n<p data-start="696" data-end="745">Premium landmark location with historical charm</p>\r\n</li>\r\n 	<li data-start="746" data-end="812">\r\n<p data-start="748" data-end="812">Ideal for luxury residence, heritage venue, or cultural estate</p>\r\n</li>\r\n</ul>\r\n<p data-start="814" data-end="838">📋 <strong data-start="817" data-end="838">Property Details:</strong></p>\r\n<p data-start="840" data-end="1147">🛏️ <strong data-start="844" data-end="857">Bedrooms:</strong> 22<br data-start="861" data-end="864" />🛁 <strong data-start="867" data-end="881">Bathrooms:</strong> 5<br data-start="883" data-end="886" />📐 <strong data-start="889" data-end="909">Area (Built-up):</strong> 4,800 sq. ft.<br data-start="980" data-end="983" />🏗️ <strong data-start="987" data-end="1005">Property Type:</strong> Heritage Palace / Luxury Estate<br data-start="1037" data-end="1040" />📍 <strong data-start="1043" data-end="1056">Location:</strong> Jaipur, Rajasthan<br data-start="1074" data-end="1077" />💰 <strong data-start="1080" data-end="1090">Price:</strong> ₹15 Crores Onwards<br data-start="1109" data-end="1112" />🚧 <strong data-start="1115" data-end="1126">Status:</strong> Ready for Possession</p>','Regal Crest Taj Villa','','publish','closed','closed','','regal-crest-taj-villa','','','2025-07-24 18:19:59','2025-07-24 18:19:59','',0,'http://localhost/wordpress/?post_type=property&#038;p=55',0,'property','',0);
INSERT INTO `wp_posts` VALUES (56,1,'2025-07-23 16:44:58','2025-07-23 16:44:58','','pexels-nattapat-siriwan-9284-51212','','inherit','open','closed','','pexels-nattapat-siriwan-9284-51212','','','2025-07-23 16:44:58','2025-07-23 16:44:58','',55,'http://localhost/wordpress/wp-content/uploads/2025/07/pexels-nattapat-siriwan-9284-51212.jpeg',0,'attachment','image/jpeg',0);
INSERT INTO `wp_posts` VALUES (61,1,'2025-07-25 14:17:52','2025-07-25 14:17:52','Name: Joy\nEmail: joychoudhury123dhn@gmail.com\n\nMessage:\nI want to buy\n\nProperty: Stonehill Heart Living\nLink: http://localhost/wordpress/properties/stonehill-house-premium-luxury-living/','Inquiry from Joy – Property: Stonehill Heart Living','','publish','closed','closed','','inquiry-from-joy-property-stonehill-heart-living','','','2025-07-25 14:17:52','2025-07-25 14:17:52','',0,'http://localhost/wordpress/inquiry/inquiry-from-joy-property-stonehill-heart-living/',0,'inquiry','',0);
INSERT INTO `wp_posts` VALUES (63,1,'2025-07-25 16:02:10','2025-07-25 16:02:10','Name: Joy\nEmail: joychoudhury123dhn@gmail.com\n\nMessage:\nI want to buy this property\n\nProperty: Maplewood Countryside Living\nLink: http://localhost/wordpress/properties/maplewood-elegant-countryside-living/','Inquiry from Joy – Property: Maplewood Countryside Living','','publish','closed','closed','','inquiry-from-joy-property-maplewood-countryside-living','','','2025-07-25 16:02:10','2025-07-25 16:02:10','',0,'http://localhost/wordpress/inquiry/inquiry-from-joy-property-maplewood-countryside-living/',0,'inquiry','',0);
INSERT INTO `wp_posts` VALUES (64,1,'2025-07-25 16:02:10','2025-07-25 16:02:10','Name: Joy\nEmail: joychoudhury123dhn@gmail.com\nMessage:\nI want to buy this property','Inquiry from Joy','','publish','closed','closed','','inquiry-from-joy','','','2025-07-25 16:02:10','2025-07-25 16:02:10','',0,'http://localhost/wordpress/inquiry/inquiry-from-joy/',0,'inquiry','',0);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_options` (
  `option_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=625 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES (1,'cron','a:12:{i:1753463858;a:1:{s:33:"wpvivid_clean_backup_record_event";a:1:{s:32:"a8cf63fecab3eb3edf6760bc02f258a6";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;b:0;}}}}i:1753463918;a:1:{s:28:"wpvivid_task_monitor_event_2";a:1:{s:32:"e4e2180ffd3295cd9b15e799b3cf6ef3";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;s:21:"wpvivid-85fe390fd6fc2";}}}}i:1753466427;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1753477227;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1753477251;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1753477258;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1753480826;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1753482626;a:1:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1753484426;a:1:{s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1753563731;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1753650027;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}','on');
INSERT INTO `wp_options` VALUES (2,'siteurl','http://localhost/wordpress','on');
INSERT INTO `wp_options` VALUES (3,'home','http://localhost/wordpress','on');
INSERT INTO `wp_options` VALUES (4,'blogname','JoyWSI','on');
INSERT INTO `wp_options` VALUES (5,'blogdescription','','on');
INSERT INTO `wp_options` VALUES (6,'users_can_register','0','on');
INSERT INTO `wp_options` VALUES (7,'admin_email','joycoolxx@gmail.com','on');
INSERT INTO `wp_options` VALUES (8,'start_of_week','1','on');
INSERT INTO `wp_options` VALUES (9,'use_balanceTags','0','on');
INSERT INTO `wp_options` VALUES (10,'use_smilies','1','on');
INSERT INTO `wp_options` VALUES (11,'require_name_email','1','on');
INSERT INTO `wp_options` VALUES (12,'comments_notify','1','on');
INSERT INTO `wp_options` VALUES (13,'posts_per_rss','10','on');
INSERT INTO `wp_options` VALUES (14,'rss_use_excerpt','0','on');
INSERT INTO `wp_options` VALUES (15,'mailserver_url','mail.example.com','on');
INSERT INTO `wp_options` VALUES (16,'mailserver_login','login@example.com','on');
INSERT INTO `wp_options` VALUES (17,'mailserver_pass','','on');
INSERT INTO `wp_options` VALUES (18,'mailserver_port','110','on');
INSERT INTO `wp_options` VALUES (19,'default_category','1','on');
INSERT INTO `wp_options` VALUES (20,'default_comment_status','open','on');
INSERT INTO `wp_options` VALUES (21,'default_ping_status','open','on');
INSERT INTO `wp_options` VALUES (22,'default_pingback_flag','1','on');
INSERT INTO `wp_options` VALUES (23,'posts_per_page','10','on');
INSERT INTO `wp_options` VALUES (24,'date_format','F j, Y','on');
INSERT INTO `wp_options` VALUES (25,'time_format','g:i a','on');
INSERT INTO `wp_options` VALUES (26,'links_updated_date_format','F j, Y g:i a','on');
INSERT INTO `wp_options` VALUES (27,'comment_moderation','0','on');
INSERT INTO `wp_options` VALUES (28,'moderation_notify','1','on');
INSERT INTO `wp_options` VALUES (29,'permalink_structure','/%postname%/','on');
INSERT INTO `wp_options` VALUES (30,'rewrite_rules','a:114:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:13:"properties/?$";s:28:"index.php?post_type=property";s:43:"properties/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=property&feed=$matches[1]";s:38:"properties/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=property&feed=$matches[1]";s:30:"properties/page/([0-9]{1,})/?$";s:46:"index.php?post_type=property&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?property_type=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?property_type=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:46:"index.php?property_type=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?property_type=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:35:"index.php?property_type=$matches[1]";s:38:"properties/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:48:"properties/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:68:"properties/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"properties/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"properties/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"properties/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:27:"properties/([^/]+)/embed/?$";s:41:"index.php?property=$matches[1]&embed=true";s:31:"properties/([^/]+)/trackback/?$";s:35:"index.php?property=$matches[1]&tb=1";s:51:"properties/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?property=$matches[1]&feed=$matches[2]";s:46:"properties/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?property=$matches[1]&feed=$matches[2]";s:39:"properties/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?property=$matches[1]&paged=$matches[2]";s:46:"properties/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?property=$matches[1]&cpage=$matches[2]";s:35:"properties/([^/]+)(?:/([0-9]+))?/?$";s:47:"index.php?property=$matches[1]&page=$matches[2]";s:27:"properties/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"properties/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"properties/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"properties/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"properties/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"properties/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}','on');
INSERT INTO `wp_options` VALUES (31,'hack_file','0','on');
INSERT INTO `wp_options` VALUES (32,'blog_charset','UTF-8','on');
INSERT INTO `wp_options` VALUES (33,'moderation_keys','','off');
INSERT INTO `wp_options` VALUES (34,'active_plugins','a:1:{i:0;s:47:"wpvivid-backuprestore/wpvivid-backuprestore.php";}','on');
INSERT INTO `wp_options` VALUES (35,'category_base','','on');
INSERT INTO `wp_options` VALUES (36,'ping_sites','https://rpc.pingomatic.com/','on');
INSERT INTO `wp_options` VALUES (37,'comment_max_links','2','on');
INSERT INTO `wp_options` VALUES (38,'gmt_offset','0','on');
INSERT INTO `wp_options` VALUES (39,'default_email_category','1','on');
INSERT INTO `wp_options` VALUES (40,'recently_edited','a:2:{i:0;s:71:"D:\\xampp\\htdocs\\wordpress/wp-content/themes/real-estate-theme/style.css";i:1;s:0:"";}','off');
INSERT INTO `wp_options` VALUES (41,'template','real-estate-theme','on');
INSERT INTO `wp_options` VALUES (42,'stylesheet','real-estate-theme','on');
INSERT INTO `wp_options` VALUES (43,'comment_registration','0','on');
INSERT INTO `wp_options` VALUES (44,'html_type','text/html','on');
INSERT INTO `wp_options` VALUES (45,'use_trackback','0','on');
INSERT INTO `wp_options` VALUES (46,'default_role','subscriber','on');
INSERT INTO `wp_options` VALUES (47,'db_version','60421','on');
INSERT INTO `wp_options` VALUES (48,'uploads_use_yearmonth_folders','1','on');
INSERT INTO `wp_options` VALUES (49,'upload_path','','on');
INSERT INTO `wp_options` VALUES (50,'blog_public','1','on');
INSERT INTO `wp_options` VALUES (51,'default_link_category','2','on');
INSERT INTO `wp_options` VALUES (52,'show_on_front','posts','on');
INSERT INTO `wp_options` VALUES (53,'tag_base','','on');
INSERT INTO `wp_options` VALUES (54,'show_avatars','1','on');
INSERT INTO `wp_options` VALUES (55,'avatar_rating','G','on');
INSERT INTO `wp_options` VALUES (56,'upload_url_path','','on');
INSERT INTO `wp_options` VALUES (57,'thumbnail_size_w','150','on');
INSERT INTO `wp_options` VALUES (58,'thumbnail_size_h','150','on');
INSERT INTO `wp_options` VALUES (59,'thumbnail_crop','1','on');
INSERT INTO `wp_options` VALUES (60,'medium_size_w','300','on');
INSERT INTO `wp_options` VALUES (61,'medium_size_h','300','on');
INSERT INTO `wp_options` VALUES (62,'avatar_default','mystery','on');
INSERT INTO `wp_options` VALUES (63,'large_size_w','1024','on');
INSERT INTO `wp_options` VALUES (64,'large_size_h','1024','on');
INSERT INTO `wp_options` VALUES (65,'image_default_link_type','none','on');
INSERT INTO `wp_options` VALUES (66,'image_default_size','','on');
INSERT INTO `wp_options` VALUES (67,'image_default_align','','on');
INSERT INTO `wp_options` VALUES (68,'close_comments_for_old_posts','0','on');
INSERT INTO `wp_options` VALUES (69,'close_comments_days_old','14','on');
INSERT INTO `wp_options` VALUES (70,'thread_comments','1','on');
INSERT INTO `wp_options` VALUES (71,'thread_comments_depth','5','on');
INSERT INTO `wp_options` VALUES (72,'page_comments','0','on');
INSERT INTO `wp_options` VALUES (73,'comments_per_page','50','on');
INSERT INTO `wp_options` VALUES (74,'default_comments_page','newest','on');
INSERT INTO `wp_options` VALUES (75,'comment_order','asc','on');
INSERT INTO `wp_options` VALUES (76,'sticky_posts','a:0:{}','on');
INSERT INTO `wp_options` VALUES (77,'widget_categories','a:0:{}','on');
INSERT INTO `wp_options` VALUES (78,'widget_text','a:0:{}','on');
INSERT INTO `wp_options` VALUES (79,'widget_rss','a:0:{}','on');
INSERT INTO `wp_options` VALUES (80,'uninstall_plugins','a:0:{}','off');
INSERT INTO `wp_options` VALUES (81,'timezone_string','','on');
INSERT INTO `wp_options` VALUES (82,'page_for_posts','0','on');
INSERT INTO `wp_options` VALUES (83,'page_on_front','0','on');
INSERT INTO `wp_options` VALUES (84,'default_post_format','0','on');
INSERT INTO `wp_options` VALUES (85,'link_manager_enabled','0','on');
INSERT INTO `wp_options` VALUES (86,'finished_splitting_shared_terms','1','on');
INSERT INTO `wp_options` VALUES (87,'site_icon','0','on');
INSERT INTO `wp_options` VALUES (88,'medium_large_size_w','768','on');
INSERT INTO `wp_options` VALUES (89,'medium_large_size_h','0','on');
INSERT INTO `wp_options` VALUES (90,'wp_page_for_privacy_policy','3','on');
INSERT INTO `wp_options` VALUES (91,'show_comments_cookies_opt_in','1','on');
INSERT INTO `wp_options` VALUES (92,'admin_email_lifespan','1768510826','on');
INSERT INTO `wp_options` VALUES (93,'disallowed_keys','','off');
INSERT INTO `wp_options` VALUES (94,'comment_previously_approved','1','on');
INSERT INTO `wp_options` VALUES (95,'auto_plugin_theme_update_emails','a:0:{}','off');
INSERT INTO `wp_options` VALUES (96,'auto_update_core_dev','enabled','on');
INSERT INTO `wp_options` VALUES (97,'auto_update_core_minor','enabled','on');
INSERT INTO `wp_options` VALUES (98,'auto_update_core_major','enabled','on');
INSERT INTO `wp_options` VALUES (99,'wp_force_deactivated_plugins','a:0:{}','on');
INSERT INTO `wp_options` VALUES (100,'wp_attachment_pages_enabled','0','on');
INSERT INTO `wp_options` VALUES (101,'initial_db_version','60421','on');
INSERT INTO `wp_options` VALUES (102,'wp_user_roles','a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}','on');
INSERT INTO `wp_options` VALUES (103,'fresh_site','0','off');
INSERT INTO `wp_options` VALUES (104,'user_count','1','off');
INSERT INTO `wp_options` VALUES (105,'widget_block','a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:227:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (106,'sidebars_widgets','a:6:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:8:"footer-1";a:0:{}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:13:"array_version";i:3;}','auto');
INSERT INTO `wp_options` VALUES (107,'widget_pages','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (108,'widget_calendar','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (109,'widget_archives','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (110,'widget_media_audio','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (111,'widget_media_image','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (112,'widget_media_gallery','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (113,'widget_media_video','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (114,'widget_meta','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (115,'widget_search','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (116,'widget_recent-posts','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (117,'widget_recent-comments','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (118,'widget_tag_cloud','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (119,'widget_nav_menu','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (120,'widget_custom_html','a:1:{s:12:"_multiwidget";i:1;}','auto');
INSERT INTO `wp_options` VALUES (121,'_transient_wp_core_block_css_files','a:2:{s:7:"version";s:5:"6.8.2";s:5:"files";a:536:{i:0;s:23:"archives/editor-rtl.css";i:1;s:27:"archives/editor-rtl.min.css";i:2;s:19:"archives/editor.css";i:3;s:23:"archives/editor.min.css";i:4;s:22:"archives/style-rtl.css";i:5;s:26:"archives/style-rtl.min.css";i:6;s:18:"archives/style.css";i:7;s:22:"archives/style.min.css";i:8;s:20:"audio/editor-rtl.css";i:9;s:24:"audio/editor-rtl.min.css";i:10;s:16:"audio/editor.css";i:11;s:20:"audio/editor.min.css";i:12;s:19:"audio/style-rtl.css";i:13;s:23:"audio/style-rtl.min.css";i:14;s:15:"audio/style.css";i:15;s:19:"audio/style.min.css";i:16;s:19:"audio/theme-rtl.css";i:17;s:23:"audio/theme-rtl.min.css";i:18;s:15:"audio/theme.css";i:19;s:19:"audio/theme.min.css";i:20;s:21:"avatar/editor-rtl.css";i:21;s:25:"avatar/editor-rtl.min.css";i:22;s:17:"avatar/editor.css";i:23;s:21:"avatar/editor.min.css";i:24;s:20:"avatar/style-rtl.css";i:25;s:24:"avatar/style-rtl.min.css";i:26;s:16:"avatar/style.css";i:27;s:20:"avatar/style.min.css";i:28;s:21:"button/editor-rtl.css";i:29;s:25:"button/editor-rtl.min.css";i:30;s:17:"button/editor.css";i:31;s:21:"button/editor.min.css";i:32;s:20:"button/style-rtl.css";i:33;s:24:"button/style-rtl.min.css";i:34;s:16:"button/style.css";i:35;s:20:"button/style.min.css";i:36;s:22:"buttons/editor-rtl.css";i:37;s:26:"buttons/editor-rtl.min.css";i:38;s:18:"buttons/editor.css";i:39;s:22:"buttons/editor.min.css";i:40;s:21:"buttons/style-rtl.css";i:41;s:25:"buttons/style-rtl.min.css";i:42;s:17:"buttons/style.css";i:43;s:21:"buttons/style.min.css";i:44;s:22:"calendar/style-rtl.css";i:45;s:26:"calendar/style-rtl.min.css";i:46;s:18:"calendar/style.css";i:47;s:22:"calendar/style.min.css";i:48;s:25:"categories/editor-rtl.css";i:49;s:29:"categories/editor-rtl.min.css";i:50;s:21:"categories/editor.css";i:51;s:25:"categories/editor.min.css";i:52;s:24:"categories/style-rtl.css";i:53;s:28:"categories/style-rtl.min.css";i:54;s:20:"categories/style.css";i:55;s:24:"categories/style.min.css";i:56;s:19:"code/editor-rtl.css";i:57;s:23:"code/editor-rtl.min.css";i:58;s:15:"code/editor.css";i:59;s:19:"code/editor.min.css";i:60;s:18:"code/style-rtl.css";i:61;s:22:"code/style-rtl.min.css";i:62;s:14:"code/style.css";i:63;s:18:"code/style.min.css";i:64;s:18:"code/theme-rtl.css";i:65;s:22:"code/theme-rtl.min.css";i:66;s:14:"code/theme.css";i:67;s:18:"code/theme.min.css";i:68;s:22:"columns/editor-rtl.css";i:69;s:26:"columns/editor-rtl.min.css";i:70;s:18:"columns/editor.css";i:71;s:22:"columns/editor.min.css";i:72;s:21:"columns/style-rtl.css";i:73;s:25:"columns/style-rtl.min.css";i:74;s:17:"columns/style.css";i:75;s:21:"columns/style.min.css";i:76;s:33:"comment-author-name/style-rtl.css";i:77;s:37:"comment-author-name/style-rtl.min.css";i:78;s:29:"comment-author-name/style.css";i:79;s:33:"comment-author-name/style.min.css";i:80;s:29:"comment-content/style-rtl.css";i:81;s:33:"comment-content/style-rtl.min.css";i:82;s:25:"comment-content/style.css";i:83;s:29:"comment-content/style.min.css";i:84;s:26:"comment-date/style-rtl.css";i:85;s:30:"comment-date/style-rtl.min.css";i:86;s:22:"comment-date/style.css";i:87;s:26:"comment-date/style.min.css";i:88;s:31:"comment-edit-link/style-rtl.css";i:89;s:35:"comment-edit-link/style-rtl.min.css";i:90;s:27:"comment-edit-link/style.css";i:91;s:31:"comment-edit-link/style.min.css";i:92;s:32:"comment-reply-link/style-rtl.css";i:93;s:36:"comment-reply-link/style-rtl.min.css";i:94;s:28:"comment-reply-link/style.css";i:95;s:32:"comment-reply-link/style.min.css";i:96;s:30:"comment-template/style-rtl.css";i:97;s:34:"comment-template/style-rtl.min.css";i:98;s:26:"comment-template/style.css";i:99;s:30:"comment-template/style.min.css";i:100;s:42:"comments-pagination-numbers/editor-rtl.css";i:101;s:46:"comments-pagination-numbers/editor-rtl.min.css";i:102;s:38:"comments-pagination-numbers/editor.css";i:103;s:42:"comments-pagination-numbers/editor.min.css";i:104;s:34:"comments-pagination/editor-rtl.css";i:105;s:38:"comments-pagination/editor-rtl.min.css";i:106;s:30:"comments-pagination/editor.css";i:107;s:34:"comments-pagination/editor.min.css";i:108;s:33:"comments-pagination/style-rtl.css";i:109;s:37:"comments-pagination/style-rtl.min.css";i:110;s:29:"comments-pagination/style.css";i:111;s:33:"comments-pagination/style.min.css";i:112;s:29:"comments-title/editor-rtl.css";i:113;s:33:"comments-title/editor-rtl.min.css";i:114;s:25:"comments-title/editor.css";i:115;s:29:"comments-title/editor.min.css";i:116;s:23:"comments/editor-rtl.css";i:117;s:27:"comments/editor-rtl.min.css";i:118;s:19:"comments/editor.css";i:119;s:23:"comments/editor.min.css";i:120;s:22:"comments/style-rtl.css";i:121;s:26:"comments/style-rtl.min.css";i:122;s:18:"comments/style.css";i:123;s:22:"comments/style.min.css";i:124;s:20:"cover/editor-rtl.css";i:125;s:24:"cover/editor-rtl.min.css";i:126;s:16:"cover/editor.css";i:127;s:20:"cover/editor.min.css";i:128;s:19:"cover/style-rtl.css";i:129;s:23:"cover/style-rtl.min.css";i:130;s:15:"cover/style.css";i:131;s:19:"cover/style.min.css";i:132;s:22:"details/editor-rtl.css";i:133;s:26:"details/editor-rtl.min.css";i:134;s:18:"details/editor.css";i:135;s:22:"details/editor.min.css";i:136;s:21:"details/style-rtl.css";i:137;s:25:"details/style-rtl.min.css";i:138;s:17:"details/style.css";i:139;s:21:"details/style.min.css";i:140;s:20:"embed/editor-rtl.css";i:141;s:24:"embed/editor-rtl.min.css";i:142;s:16:"embed/editor.css";i:143;s:20:"embed/editor.min.css";i:144;s:19:"embed/style-rtl.css";i:145;s:23:"embed/style-rtl.min.css";i:146;s:15:"embed/style.css";i:147;s:19:"embed/style.min.css";i:148;s:19:"embed/theme-rtl.css";i:149;s:23:"embed/theme-rtl.min.css";i:150;s:15:"embed/theme.css";i:151;s:19:"embed/theme.min.css";i:152;s:19:"file/editor-rtl.css";i:153;s:23:"file/editor-rtl.min.css";i:154;s:15:"file/editor.css";i:155;s:19:"file/editor.min.css";i:156;s:18:"file/style-rtl.css";i:157;s:22:"file/style-rtl.min.css";i:158;s:14:"file/style.css";i:159;s:18:"file/style.min.css";i:160;s:23:"footnotes/style-rtl.css";i:161;s:27:"footnotes/style-rtl.min.css";i:162;s:19:"footnotes/style.css";i:163;s:23:"footnotes/style.min.css";i:164;s:23:"freeform/editor-rtl.css";i:165;s:27:"freeform/editor-rtl.min.css";i:166;s:19:"freeform/editor.css";i:167;s:23:"freeform/editor.min.css";i:168;s:22:"gallery/editor-rtl.css";i:169;s:26:"gallery/editor-rtl.min.css";i:170;s:18:"gallery/editor.css";i:171;s:22:"gallery/editor.min.css";i:172;s:21:"gallery/style-rtl.css";i:173;s:25:"gallery/style-rtl.min.css";i:174;s:17:"gallery/style.css";i:175;s:21:"gallery/style.min.css";i:176;s:21:"gallery/theme-rtl.css";i:177;s:25:"gallery/theme-rtl.min.css";i:178;s:17:"gallery/theme.css";i:179;s:21:"gallery/theme.min.css";i:180;s:20:"group/editor-rtl.css";i:181;s:24:"group/editor-rtl.min.css";i:182;s:16:"group/editor.css";i:183;s:20:"group/editor.min.css";i:184;s:19:"group/style-rtl.css";i:185;s:23:"group/style-rtl.min.css";i:186;s:15:"group/style.css";i:187;s:19:"group/style.min.css";i:188;s:19:"group/theme-rtl.css";i:189;s:23:"group/theme-rtl.min.css";i:190;s:15:"group/theme.css";i:191;s:19:"group/theme.min.css";i:192;s:21:"heading/style-rtl.css";i:193;s:25:"heading/style-rtl.min.css";i:194;s:17:"heading/style.css";i:195;s:21:"heading/style.min.css";i:196;s:19:"html/editor-rtl.css";i:197;s:23:"html/editor-rtl.min.css";i:198;s:15:"html/editor.css";i:199;s:19:"html/editor.min.css";i:200;s:20:"image/editor-rtl.css";i:201;s:24:"image/editor-rtl.min.css";i:202;s:16:"image/editor.css";i:203;s:20:"image/editor.min.css";i:204;s:19:"image/style-rtl.css";i:205;s:23:"image/style-rtl.min.css";i:206;s:15:"image/style.css";i:207;s:19:"image/style.min.css";i:208;s:19:"image/theme-rtl.css";i:209;s:23:"image/theme-rtl.min.css";i:210;s:15:"image/theme.css";i:211;s:19:"image/theme.min.css";i:212;s:29:"latest-comments/style-rtl.css";i:213;s:33:"latest-comments/style-rtl.min.css";i:214;s:25:"latest-comments/style.css";i:215;s:29:"latest-comments/style.min.css";i:216;s:27:"latest-posts/editor-rtl.css";i:217;s:31:"latest-posts/editor-rtl.min.css";i:218;s:23:"latest-posts/editor.css";i:219;s:27:"latest-posts/editor.min.css";i:220;s:26:"latest-posts/style-rtl.css";i:221;s:30:"latest-posts/style-rtl.min.css";i:222;s:22:"latest-posts/style.css";i:223;s:26:"latest-posts/style.min.css";i:224;s:18:"list/style-rtl.css";i:225;s:22:"list/style-rtl.min.css";i:226;s:14:"list/style.css";i:227;s:18:"list/style.min.css";i:228;s:22:"loginout/style-rtl.css";i:229;s:26:"loginout/style-rtl.min.css";i:230;s:18:"loginout/style.css";i:231;s:22:"loginout/style.min.css";i:232;s:25:"media-text/editor-rtl.css";i:233;s:29:"media-text/editor-rtl.min.css";i:234;s:21:"media-text/editor.css";i:235;s:25:"media-text/editor.min.css";i:236;s:24:"media-text/style-rtl.css";i:237;s:28:"media-text/style-rtl.min.css";i:238;s:20:"media-text/style.css";i:239;s:24:"media-text/style.min.css";i:240;s:19:"more/editor-rtl.css";i:241;s:23:"more/editor-rtl.min.css";i:242;s:15:"more/editor.css";i:243;s:19:"more/editor.min.css";i:244;s:30:"navigation-link/editor-rtl.css";i:245;s:34:"navigation-link/editor-rtl.min.css";i:246;s:26:"navigation-link/editor.css";i:247;s:30:"navigation-link/editor.min.css";i:248;s:29:"navigation-link/style-rtl.css";i:249;s:33:"navigation-link/style-rtl.min.css";i:250;s:25:"navigation-link/style.css";i:251;s:29:"navigation-link/style.min.css";i:252;s:33:"navigation-submenu/editor-rtl.css";i:253;s:37:"navigation-submenu/editor-rtl.min.css";i:254;s:29:"navigation-submenu/editor.css";i:255;s:33:"navigation-submenu/editor.min.css";i:256;s:25:"navigation/editor-rtl.css";i:257;s:29:"navigation/editor-rtl.min.css";i:258;s:21:"navigation/editor.css";i:259;s:25:"navigation/editor.min.css";i:260;s:24:"navigation/style-rtl.css";i:261;s:28:"navigation/style-rtl.min.css";i:262;s:20:"navigation/style.css";i:263;s:24:"navigation/style.min.css";i:264;s:23:"nextpage/editor-rtl.css";i:265;s:27:"nextpage/editor-rtl.min.css";i:266;s:19:"nextpage/editor.css";i:267;s:23:"nextpage/editor.min.css";i:268;s:24:"page-list/editor-rtl.css";i:269;s:28:"page-list/editor-rtl.min.css";i:270;s:20:"page-list/editor.css";i:271;s:24:"page-list/editor.min.css";i:272;s:23:"page-list/style-rtl.css";i:273;s:27:"page-list/style-rtl.min.css";i:274;s:19:"page-list/style.css";i:275;s:23:"page-list/style.min.css";i:276;s:24:"paragraph/editor-rtl.css";i:277;s:28:"paragraph/editor-rtl.min.css";i:278;s:20:"paragraph/editor.css";i:279;s:24:"paragraph/editor.min.css";i:280;s:23:"paragraph/style-rtl.css";i:281;s:27:"paragraph/style-rtl.min.css";i:282;s:19:"paragraph/style.css";i:283;s:23:"paragraph/style.min.css";i:284;s:35:"post-author-biography/style-rtl.css";i:285;s:39:"post-author-biography/style-rtl.min.css";i:286;s:31:"post-author-biography/style.css";i:287;s:35:"post-author-biography/style.min.css";i:288;s:30:"post-author-name/style-rtl.css";i:289;s:34:"post-author-name/style-rtl.min.css";i:290;s:26:"post-author-name/style.css";i:291;s:30:"post-author-name/style.min.css";i:292;s:26:"post-author/editor-rtl.css";i:293;s:30:"post-author/editor-rtl.min.css";i:294;s:22:"post-author/editor.css";i:295;s:26:"post-author/editor.min.css";i:296;s:25:"post-author/style-rtl.css";i:297;s:29:"post-author/style-rtl.min.css";i:298;s:21:"post-author/style.css";i:299;s:25:"post-author/style.min.css";i:300;s:33:"post-comments-form/editor-rtl.css";i:301;s:37:"post-comments-form/editor-rtl.min.css";i:302;s:29:"post-comments-form/editor.css";i:303;s:33:"post-comments-form/editor.min.css";i:304;s:32:"post-comments-form/style-rtl.css";i:305;s:36:"post-comments-form/style-rtl.min.css";i:306;s:28:"post-comments-form/style.css";i:307;s:32:"post-comments-form/style.min.css";i:308;s:26:"post-content/style-rtl.css";i:309;s:30:"post-content/style-rtl.min.css";i:310;s:22:"post-content/style.css";i:311;s:26:"post-content/style.min.css";i:312;s:23:"post-date/style-rtl.css";i:313;s:27:"post-date/style-rtl.min.css";i:314;s:19:"post-date/style.css";i:315;s:23:"post-date/style.min.css";i:316;s:27:"post-excerpt/editor-rtl.css";i:317;s:31:"post-excerpt/editor-rtl.min.css";i:318;s:23:"post-excerpt/editor.css";i:319;s:27:"post-excerpt/editor.min.css";i:320;s:26:"post-excerpt/style-rtl.css";i:321;s:30:"post-excerpt/style-rtl.min.css";i:322;s:22:"post-excerpt/style.css";i:323;s:26:"post-excerpt/style.min.css";i:324;s:34:"post-featured-image/editor-rtl.css";i:325;s:38:"post-featured-image/editor-rtl.min.css";i:326;s:30:"post-featured-image/editor.css";i:327;s:34:"post-featured-image/editor.min.css";i:328;s:33:"post-featured-image/style-rtl.css";i:329;s:37:"post-featured-image/style-rtl.min.css";i:330;s:29:"post-featured-image/style.css";i:331;s:33:"post-featured-image/style.min.css";i:332;s:34:"post-navigation-link/style-rtl.css";i:333;s:38:"post-navigation-link/style-rtl.min.css";i:334;s:30:"post-navigation-link/style.css";i:335;s:34:"post-navigation-link/style.min.css";i:336;s:27:"post-template/style-rtl.css";i:337;s:31:"post-template/style-rtl.min.css";i:338;s:23:"post-template/style.css";i:339;s:27:"post-template/style.min.css";i:340;s:24:"post-terms/style-rtl.css";i:341;s:28:"post-terms/style-rtl.min.css";i:342;s:20:"post-terms/style.css";i:343;s:24:"post-terms/style.min.css";i:344;s:24:"post-title/style-rtl.css";i:345;s:28:"post-title/style-rtl.min.css";i:346;s:20:"post-title/style.css";i:347;s:24:"post-title/style.min.css";i:348;s:26:"preformatted/style-rtl.css";i:349;s:30:"preformatted/style-rtl.min.css";i:350;s:22:"preformatted/style.css";i:351;s:26:"preformatted/style.min.css";i:352;s:24:"pullquote/editor-rtl.css";i:353;s:28:"pullquote/editor-rtl.min.css";i:354;s:20:"pullquote/editor.css";i:355;s:24:"pullquote/editor.min.css";i:356;s:23:"pullquote/style-rtl.css";i:357;s:27:"pullquote/style-rtl.min.css";i:358;s:19:"pullquote/style.css";i:359;s:23:"pullquote/style.min.css";i:360;s:23:"pullquote/theme-rtl.css";i:361;s:27:"pullquote/theme-rtl.min.css";i:362;s:19:"pullquote/theme.css";i:363;s:23:"pullquote/theme.min.css";i:364;s:39:"query-pagination-numbers/editor-rtl.css";i:365;s:43:"query-pagination-numbers/editor-rtl.min.css";i:366;s:35:"query-pagination-numbers/editor.css";i:367;s:39:"query-pagination-numbers/editor.min.css";i:368;s:31:"query-pagination/editor-rtl.css";i:369;s:35:"query-pagination/editor-rtl.min.css";i:370;s:27:"query-pagination/editor.css";i:371;s:31:"query-pagination/editor.min.css";i:372;s:30:"query-pagination/style-rtl.css";i:373;s:34:"query-pagination/style-rtl.min.css";i:374;s:26:"query-pagination/style.css";i:375;s:30:"query-pagination/style.min.css";i:376;s:25:"query-title/style-rtl.css";i:377;s:29:"query-title/style-rtl.min.css";i:378;s:21:"query-title/style.css";i:379;s:25:"query-title/style.min.css";i:380;s:25:"query-total/style-rtl.css";i:381;s:29:"query-total/style-rtl.min.css";i:382;s:21:"query-total/style.css";i:383;s:25:"query-total/style.min.css";i:384;s:20:"query/editor-rtl.css";i:385;s:24:"query/editor-rtl.min.css";i:386;s:16:"query/editor.css";i:387;s:20:"query/editor.min.css";i:388;s:19:"quote/style-rtl.css";i:389;s:23:"quote/style-rtl.min.css";i:390;s:15:"quote/style.css";i:391;s:19:"quote/style.min.css";i:392;s:19:"quote/theme-rtl.css";i:393;s:23:"quote/theme-rtl.min.css";i:394;s:15:"quote/theme.css";i:395;s:19:"quote/theme.min.css";i:396;s:23:"read-more/style-rtl.css";i:397;s:27:"read-more/style-rtl.min.css";i:398;s:19:"read-more/style.css";i:399;s:23:"read-more/style.min.css";i:400;s:18:"rss/editor-rtl.css";i:401;s:22:"rss/editor-rtl.min.css";i:402;s:14:"rss/editor.css";i:403;s:18:"rss/editor.min.css";i:404;s:17:"rss/style-rtl.css";i:405;s:21:"rss/style-rtl.min.css";i:406;s:13:"rss/style.css";i:407;s:17:"rss/style.min.css";i:408;s:21:"search/editor-rtl.css";i:409;s:25:"search/editor-rtl.min.css";i:410;s:17:"search/editor.css";i:411;s:21:"search/editor.min.css";i:412;s:20:"search/style-rtl.css";i:413;s:24:"search/style-rtl.min.css";i:414;s:16:"search/style.css";i:415;s:20:"search/style.min.css";i:416;s:20:"search/theme-rtl.css";i:417;s:24:"search/theme-rtl.min.css";i:418;s:16:"search/theme.css";i:419;s:20:"search/theme.min.css";i:420;s:24:"separator/editor-rtl.css";i:421;s:28:"separator/editor-rtl.min.css";i:422;s:20:"separator/editor.css";i:423;s:24:"separator/editor.min.css";i:424;s:23:"separator/style-rtl.css";i:425;s:27:"separator/style-rtl.min.css";i:426;s:19:"separator/style.css";i:427;s:23:"separator/style.min.css";i:428;s:23:"separator/theme-rtl.css";i:429;s:27:"separator/theme-rtl.min.css";i:430;s:19:"separator/theme.css";i:431;s:23:"separator/theme.min.css";i:432;s:24:"shortcode/editor-rtl.css";i:433;s:28:"shortcode/editor-rtl.min.css";i:434;s:20:"shortcode/editor.css";i:435;s:24:"shortcode/editor.min.css";i:436;s:24:"site-logo/editor-rtl.css";i:437;s:28:"site-logo/editor-rtl.min.css";i:438;s:20:"site-logo/editor.css";i:439;s:24:"site-logo/editor.min.css";i:440;s:23:"site-logo/style-rtl.css";i:441;s:27:"site-logo/style-rtl.min.css";i:442;s:19:"site-logo/style.css";i:443;s:23:"site-logo/style.min.css";i:444;s:27:"site-tagline/editor-rtl.css";i:445;s:31:"site-tagline/editor-rtl.min.css";i:446;s:23:"site-tagline/editor.css";i:447;s:27:"site-tagline/editor.min.css";i:448;s:26:"site-tagline/style-rtl.css";i:449;s:30:"site-tagline/style-rtl.min.css";i:450;s:22:"site-tagline/style.css";i:451;s:26:"site-tagline/style.min.css";i:452;s:25:"site-title/editor-rtl.css";i:453;s:29:"site-title/editor-rtl.min.css";i:454;s:21:"site-title/editor.css";i:455;s:25:"site-title/editor.min.css";i:456;s:24:"site-title/style-rtl.css";i:457;s:28:"site-title/style-rtl.min.css";i:458;s:20:"site-title/style.css";i:459;s:24:"site-title/style.min.css";i:460;s:26:"social-link/editor-rtl.css";i:461;s:30:"social-link/editor-rtl.min.css";i:462;s:22:"social-link/editor.css";i:463;s:26:"social-link/editor.min.css";i:464;s:27:"social-links/editor-rtl.css";i:465;s:31:"social-links/editor-rtl.min.css";i:466;s:23:"social-links/editor.css";i:467;s:27:"social-links/editor.min.css";i:468;s:26:"social-links/style-rtl.css";i:469;s:30:"social-links/style-rtl.min.css";i:470;s:22:"social-links/style.css";i:471;s:26:"social-links/style.min.css";i:472;s:21:"spacer/editor-rtl.css";i:473;s:25:"spacer/editor-rtl.min.css";i:474;s:17:"spacer/editor.css";i:475;s:21:"spacer/editor.min.css";i:476;s:20:"spacer/style-rtl.css";i:477;s:24:"spacer/style-rtl.min.css";i:478;s:16:"spacer/style.css";i:479;s:20:"spacer/style.min.css";i:480;s:20:"table/editor-rtl.css";i:481;s:24:"table/editor-rtl.min.css";i:482;s:16:"table/editor.css";i:483;s:20:"table/editor.min.css";i:484;s:19:"table/style-rtl.css";i:485;s:23:"table/style-rtl.min.css";i:486;s:15:"table/style.css";i:487;s:19:"table/style.min.css";i:488;s:19:"table/theme-rtl.css";i:489;s:23:"table/theme-rtl.min.css";i:490;s:15:"table/theme.css";i:491;s:19:"table/theme.min.css";i:492;s:24:"tag-cloud/editor-rtl.css";i:493;s:28:"tag-cloud/editor-rtl.min.css";i:494;s:20:"tag-cloud/editor.css";i:495;s:24:"tag-cloud/editor.min.css";i:496;s:23:"tag-cloud/style-rtl.css";i:497;s:27:"tag-cloud/style-rtl.min.css";i:498;s:19:"tag-cloud/style.css";i:499;s:23:"tag-cloud/style.min.css";i:500;s:28:"template-part/editor-rtl.css";i:501;s:32:"template-part/editor-rtl.min.css";i:502;s:24:"template-part/editor.css";i:503;s:28:"template-part/editor.min.css";i:504;s:27:"template-part/theme-rtl.css";i:505;s:31:"template-part/theme-rtl.min.css";i:506;s:23:"template-part/theme.css";i:507;s:27:"template-part/theme.min.css";i:508;s:30:"term-description/style-rtl.css";i:509;s:34:"term-description/style-rtl.min.css";i:510;s:26:"term-description/style.css";i:511;s:30:"term-description/style.min.css";i:512;s:27:"text-columns/editor-rtl.css";i:513;s:31:"text-columns/editor-rtl.min.css";i:514;s:23:"text-columns/editor.css";i:515;s:27:"text-columns/editor.min.css";i:516;s:26:"text-columns/style-rtl.css";i:517;s:30:"text-columns/style-rtl.min.css";i:518;s:22:"text-columns/style.css";i:519;s:26:"text-columns/style.min.css";i:520;s:19:"verse/style-rtl.css";i:521;s:23:"verse/style-rtl.min.css";i:522;s:15:"verse/style.css";i:523;s:19:"verse/style.min.css";i:524;s:20:"video/editor-rtl.css";i:525;s:24:"video/editor-rtl.min.css";i:526;s:16:"video/editor.css";i:527;s:20:"video/editor.min.css";i:528;s:19:"video/style-rtl.css";i:529;s:23:"video/style-rtl.min.css";i:530;s:15:"video/style.css";i:531;s:19:"video/style.min.css";i:532;s:19:"video/theme-rtl.css";i:533;s:23:"video/theme-rtl.min.css";i:534;s:15:"video/theme.css";i:535;s:19:"video/theme.min.css";}}','on');
INSERT INTO `wp_options` VALUES (127,'recovery_keys','a:1:{s:22:"UXrjztBQ29hR4fuXManb5c";a:2:{s:10:"hashed_key";s:49:"$generic$319yvTbchRdqP7fKfLnNij_iMcqZdvqOhUsZ_UHf";s:10:"created_at";i:1753378106;}}','off');
INSERT INTO `wp_options` VALUES (129,'theme_mods_twentytwentyfive','a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1752988693;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}','off');
INSERT INTO `wp_options` VALUES (130,'_transient_wp_styles_for_blocks','a:2:{s:4:"hash";s:32:"8c7d46a72d7d4591fc1dd9485bedb304";s:6:"blocks";a:5:{s:11:"core/button";s:0:"";s:14:"core/site-logo";s:0:"";s:18:"core/post-template";s:120:":where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}";s:12:"core/columns";s:102:":where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}";s:14:"core/pullquote";s:69:":root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}";}}','on');
INSERT INTO `wp_options` VALUES (132,'_site_transient_update_core','O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-6.8.2.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-6.8.2.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-6.8.2-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-6.8.2-new-bundled.zip";s:7:"partial";s:0:"";s:8:"rollback";s:0:"";}s:7:"current";s:5:"6.8.2";s:7:"version";s:5:"6.8.2";s:11:"php_version";s:6:"7.2.24";s:13:"mysql_version";s:5:"5.5.5";s:11:"new_bundled";s:3:"6.7";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1753463782;s:15:"version_checked";s:5:"6.8.2";s:12:"translations";a:0:{}}','off');
INSERT INTO `wp_options` VALUES (136,'_site_transient_update_themes','O:8:"stdClass":5:{s:12:"last_checked";i:1753463785;s:7:"checked";a:4:{s:17:"real-estate-theme";s:3:"1.0";s:16:"twentytwentyfive";s:3:"1.3";s:16:"twentytwentyfour";s:3:"1.3";s:17:"twentytwentythree";s:3:"1.6";}s:8:"response";a:0:{}s:9:"no_update";a:3:{s:16:"twentytwentyfive";a:6:{s:5:"theme";s:16:"twentytwentyfive";s:11:"new_version";s:3:"1.2";s:3:"url";s:46:"https://wordpress.org/themes/twentytwentyfive/";s:7:"package";s:62:"https://downloads.wordpress.org/theme/twentytwentyfive.1.2.zip";s:8:"requires";s:3:"6.7";s:12:"requires_php";s:3:"7.2";}s:16:"twentytwentyfour";a:6:{s:5:"theme";s:16:"twentytwentyfour";s:11:"new_version";s:3:"1.3";s:3:"url";s:46:"https://wordpress.org/themes/twentytwentyfour/";s:7:"package";s:62:"https://downloads.wordpress.org/theme/twentytwentyfour.1.3.zip";s:8:"requires";s:3:"6.4";s:12:"requires_php";s:3:"7.0";}s:17:"twentytwentythree";a:6:{s:5:"theme";s:17:"twentytwentythree";s:11:"new_version";s:3:"1.6";s:3:"url";s:47:"https://wordpress.org/themes/twentytwentythree/";s:7:"package";s:63:"https://downloads.wordpress.org/theme/twentytwentythree.1.6.zip";s:8:"requires";s:3:"6.1";s:12:"requires_php";s:3:"5.6";}}s:12:"translations";a:0:{}}','off');
INSERT INTO `wp_options` VALUES (137,'_site_transient_timeout_browser_7ddeda88d0c599cc494da0dece6554d5','1753563656','off');
INSERT INTO `wp_options` VALUES (138,'_site_transient_browser_7ddeda88d0c599cc494da0dece6554d5','a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:9:"138.0.0.0";s:8:"platform";s:7:"Windows";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}','off');
INSERT INTO `wp_options` VALUES (139,'_site_transient_timeout_php_check_da775d00ae55849f14f81cf79fc50d46','1753563657','off');
INSERT INTO `wp_options` VALUES (140,'_site_transient_php_check_da775d00ae55849f14f81cf79fc50d46','a:5:{s:19:"recommended_version";s:3:"8.3";s:15:"minimum_version";s:6:"7.2.24";s:12:"is_supported";b:0;s:9:"is_secure";b:1;s:13:"is_acceptable";b:1;}','off');
INSERT INTO `wp_options` VALUES (142,'can_compress_scripts','1','on');
INSERT INTO `wp_options` VALUES (155,'_site_transient_wp_plugin_dependencies_plugin_data','a:0:{}','off');
INSERT INTO `wp_options` VALUES (156,'recently_activated','a:0:{}','off');
INSERT INTO `wp_options` VALUES (161,'finished_updating_comment_type','1','auto');
INSERT INTO `wp_options` VALUES (176,'current_theme','Real Estate Theme','auto');
INSERT INTO `wp_options` VALUES (177,'theme_mods_real-estate-theme','a:3:{i:0;b:0;s:18:"nav_menu_locations";a:3:{s:9:"main_menu";i:5;s:9:"main-menu";i:5;s:11:"mobile-menu";i:5;}s:18:"custom_css_post_id";i:-1;}','on');
INSERT INTO `wp_options` VALUES (178,'theme_switched','','auto');
INSERT INTO `wp_options` VALUES (243,'nav_menu_options','a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}','off');
INSERT INTO `wp_options` VALUES (256,'property_type_children','a:0:{}','auto');
INSERT INTO `wp_options` VALUES (272,'category_children','a:0:{}','auto');
INSERT INTO `wp_options` VALUES (303,'_transient_health-check-site-status-result','{"good":16,"recommended":5,"critical":2}','on');
INSERT INTO `wp_options` VALUES (470,'recovery_mode_email_last_sent','1753378106','auto');
INSERT INTO `wp_options` VALUES (602,'_site_transient_timeout_wp_theme_files_patterns-34ee860a62b101c77e281e757deac9db','1753464585','off');
INSERT INTO `wp_options` VALUES (603,'_site_transient_wp_theme_files_patterns-34ee860a62b101c77e281e757deac9db','a:2:{s:7:"version";s:3:"1.0";s:8:"patterns";a:0:{}}','off');
INSERT INTO `wp_options` VALUES (605,'_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a','1753474545','off');
INSERT INTO `wp_options` VALUES (606,'_site_transient_poptags_40cd750bba9870f18aada2478b24840a','O:8:"stdClass":100:{s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";i:7251;}s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";i:4904;}s:4:"post";a:3:{s:4:"name";s:4:"post";s:4:"slug";s:4:"post";s:5:"count";i:2799;}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";i:2729;}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";i:2126;}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";i:2051;}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";i:1952;}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";i:1949;}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";i:1640;}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";i:1623;}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";i:1608;}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";i:1556;}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";i:1512;}s:8:"facebook";a:3:{s:4:"name";s:8:"facebook";s:4:"slug";s:8:"facebook";s:5:"count";i:1509;}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";i:1473;}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";i:1338;}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";i:1319;}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";i:1265;}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";i:1246;}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";i:1175;}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";i:1158;}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";i:1051;}s:7:"payment";a:3:{s:4:"name";s:7:"payment";s:4:"slug";s:7:"payment";s:5:"count";i:1048;}s:10:"e-commerce";a:3:{s:4:"name";s:10:"e-commerce";s:4:"slug";s:10:"e-commerce";s:5:"count";i:1047;}s:5:"block";a:3:{s:4:"name";s:5:"block";s:4:"slug";s:5:"block";s:5:"count";i:1026;}s:9:"analytics";a:3:{s:4:"name";s:9:"analytics";s:4:"slug";s:9:"analytics";s:5:"count";i:1012;}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";i:1004;}s:9:"gutenberg";a:3:{s:4:"name";s:9:"gutenberg";s:4:"slug";s:9:"gutenberg";s:5:"count";i:991;}s:9:"elementor";a:3:{s:4:"name";s:9:"elementor";s:4:"slug";s:9:"elementor";s:5:"count";i:940;}s:6:"slider";a:3:{s:4:"name";s:6:"slider";s:4:"slug";s:6:"slider";s:5:"count";i:937;}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";i:931;}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";i:925;}s:15:"payment-gateway";a:3:{s:4:"name";s:15:"payment gateway";s:4:"slug";s:15:"payment-gateway";s:5:"count";i:918;}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";i:911;}s:4:"form";a:3:{s:4:"name";s:4:"form";s:4:"slug";s:4:"form";s:5:"count";i:908;}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";i:864;}s:6:"search";a:3:{s:4:"name";s:6:"search";s:4:"slug";s:6:"search";s:5:"count";i:838;}s:6:"editor";a:3:{s:4:"name";s:6:"editor";s:4:"slug";s:6:"editor";s:5:"count";i:810;}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";i:784;}s:12:"contact-form";a:3:{s:4:"name";s:12:"contact form";s:4:"slug";s:12:"contact-form";s:5:"count";i:778;}s:4:"menu";a:3:{s:4:"name";s:4:"menu";s:4:"slug";s:4:"menu";s:5:"count";i:766;}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";i:761;}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";i:750;}s:5:"embed";a:3:{s:4:"name";s:5:"embed";s:4:"slug";s:5:"embed";s:5:"count";i:745;}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";i:714;}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";i:709;}s:4:"ajax";a:3:{s:4:"name";s:4:"ajax";s:4:"slug";s:4:"ajax";s:5:"count";i:684;}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";i:674;}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";i:665;}s:3:"api";a:3:{s:4:"name";s:3:"api";s:4:"slug";s:3:"api";s:5:"count";i:664;}s:8:"shipping";a:3:{s:4:"name";s:8:"shipping";s:4:"slug";s:8:"shipping";s:5:"count";i:660;}s:11:"performance";a:3:{s:4:"name";s:11:"performance";s:4:"slug";s:11:"performance";s:5:"count";i:654;}s:4:"chat";a:3:{s:4:"name";s:4:"chat";s:4:"slug";s:4:"chat";s:5:"count";i:648;}s:9:"affiliate";a:3:{s:4:"name";s:9:"affiliate";s:4:"slug";s:9:"affiliate";s:5:"count";i:638;}s:9:"marketing";a:3:{s:4:"name";s:9:"marketing";s:4:"slug";s:9:"marketing";s:5:"count";i:635;}s:3:"css";a:3:{s:4:"name";s:3:"css";s:4:"slug";s:3:"css";s:5:"count";i:634;}s:9:"dashboard";a:3:{s:4:"name";s:9:"dashboard";s:4:"slug";s:9:"dashboard";s:5:"count";i:626;}s:10:"responsive";a:3:{s:4:"name";s:10:"responsive";s:4:"slug";s:10:"responsive";s:5:"count";i:625;}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";i:618;}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";i:615;}s:14:"contact-form-7";a:3:{s:4:"name";s:14:"contact form 7";s:4:"slug";s:14:"contact-form-7";s:5:"count";i:615;}s:5:"share";a:3:{s:4:"name";s:5:"share";s:4:"slug";s:5:"share";s:5:"count";i:607;}s:7:"contact";a:3:{s:4:"name";s:7:"contact";s:4:"slug";s:7:"contact";s:5:"count";i:597;}s:6:"events";a:3:{s:4:"name";s:6:"events";s:4:"slug";s:6:"events";s:5:"count";i:590;}s:5:"forms";a:3:{s:4:"name";s:5:"forms";s:4:"slug";s:5:"forms";s:5:"count";i:587;}s:3:"ads";a:3:{s:4:"name";s:3:"ads";s:4:"slug";s:3:"ads";s:5:"count";i:585;}s:6:"blocks";a:3:{s:4:"name";s:6:"blocks";s:4:"slug";s:6:"blocks";s:5:"count";i:579;}s:6:"custom";a:3:{s:4:"name";s:6:"custom";s:4:"slug";s:6:"custom";s:5:"count";i:578;}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";i:577;}s:5:"theme";a:3:{s:4:"name";s:5:"theme";s:4:"slug";s:5:"theme";s:5:"count";i:574;}s:10:"categories";a:3:{s:4:"name";s:10:"categories";s:4:"slug";s:10:"categories";s:5:"count";i:569;}s:5:"popup";a:3:{s:4:"name";s:5:"popup";s:4:"slug";s:5:"popup";s:5:"count";i:564;}s:8:"calendar";a:3:{s:4:"name";s:8:"calendar";s:4:"slug";s:8:"calendar";s:5:"count";i:557;}s:2:"ai";a:3:{s:4:"name";s:2:"AI";s:4:"slug";s:2:"ai";s:5:"count";i:557;}s:6:"button";a:3:{s:4:"name";s:6:"button";s:4:"slug";s:6:"button";s:5:"count";i:553;}s:8:"payments";a:3:{s:4:"name";s:8:"payments";s:4:"slug";s:8:"payments";s:5:"count";i:546;}s:5:"users";a:3:{s:4:"name";s:5:"users";s:4:"slug";s:5:"users";s:5:"count";i:533;}s:4:"user";a:3:{s:4:"name";s:4:"user";s:4:"slug";s:4:"user";s:5:"count";i:533;}s:4:"tags";a:3:{s:4:"name";s:4:"tags";s:4:"slug";s:4:"tags";s:5:"count";i:526;}s:10:"newsletter";a:3:{s:4:"name";s:10:"newsletter";s:4:"slug";s:10:"newsletter";s:5:"count";i:511;}s:10:"navigation";a:3:{s:4:"name";s:10:"navigation";s:4:"slug";s:10:"navigation";s:5:"count";i:510;}s:6:"mobile";a:3:{s:4:"name";s:6:"mobile";s:4:"slug";s:6:"mobile";s:5:"count";i:507;}s:12:"social-media";a:3:{s:4:"name";s:12:"social media";s:4:"slug";s:12:"social-media";s:5:"count";i:489;}s:8:"tracking";a:3:{s:4:"name";s:8:"tracking";s:4:"slug";s:8:"tracking";s:5:"count";i:488;}s:8:"checkout";a:3:{s:4:"name";s:8:"checkout";s:4:"slug";s:8:"checkout";s:5:"count";i:479;}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";i:469;}s:7:"gateway";a:3:{s:4:"name";s:7:"gateway";s:4:"slug";s:7:"gateway";s:5:"count";i:467;}s:12:"notification";a:3:{s:4:"name";s:12:"notification";s:4:"slug";s:12:"notification";s:5:"count";i:465;}s:10:"statistics";a:3:{s:4:"name";s:10:"statistics";s:4:"slug";s:10:"statistics";s:5:"count";i:463;}s:8:"redirect";a:3:{s:4:"name";s:8:"redirect";s:4:"slug";s:8:"redirect";s:5:"count";i:462;}s:9:"slideshow";a:3:{s:4:"name";s:9:"slideshow";s:4:"slug";s:9:"slideshow";s:5:"count";i:457;}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";i:456;}s:6:"import";a:3:{s:4:"name";s:6:"import";s:4:"slug";s:6:"import";s:5:"count";i:455;}s:4:"news";a:3:{s:4:"name";s:4:"news";s:4:"slug";s:4:"news";s:5:"count";i:436;}s:5:"cache";a:3:{s:4:"name";s:5:"cache";s:4:"slug";s:5:"cache";s:5:"count";i:434;}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";i:431;}s:4:"code";a:3:{s:4:"name";s:4:"code";s:4:"slug";s:4:"code";s:5:"count";i:422;}s:10:"shortcodes";a:3:{s:4:"name";s:10:"shortcodes";s:4:"slug";s:10:"shortcodes";s:5:"count";i:421;}s:7:"plugins";a:3:{s:4:"name";s:7:"plugins";s:4:"slug";s:7:"plugins";s:5:"count";i:415;}s:9:"multisite";a:3:{s:4:"name";s:9:"multisite";s:4:"slug";s:9:"multisite";s:5:"count";i:413;}}','off');
INSERT INTO `wp_options` VALUES (608,'_site_transient_timeout_theme_roots','1753465583','off');
INSERT INTO `wp_options` VALUES (609,'_site_transient_theme_roots','a:4:{s:17:"real-estate-theme";s:7:"/themes";s:16:"twentytwentyfive";s:7:"/themes";s:16:"twentytwentyfour";s:7:"/themes";s:17:"twentytwentythree";s:7:"/themes";}','off');
INSERT INTO `wp_options` VALUES (610,'_site_transient_update_plugins','O:8:"stdClass":5:{s:12:"last_checked";i:1753463791;s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:2:{s:23:"elementor/elementor.php";O:8:"stdClass":10:{s:2:"id";s:23:"w.org/plugins/elementor";s:4:"slug";s:9:"elementor";s:6:"plugin";s:23:"elementor/elementor.php";s:11:"new_version";s:6:"3.30.3";s:3:"url";s:40:"https://wordpress.org/plugins/elementor/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/elementor.3.30.3.zip";s:5:"icons";a:2:{s:2:"2x";s:62:"https://ps.w.org/elementor/assets/icon-256x256.gif?rev=3111597";s:2:"1x";s:62:"https://ps.w.org/elementor/assets/icon-128x128.gif?rev=3111597";}s:7:"banners";a:2:{s:2:"2x";s:65:"https://ps.w.org/elementor/assets/banner-1544x500.png?rev=3164133";s:2:"1x";s:64:"https://ps.w.org/elementor/assets/banner-772x250.png?rev=3164133";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"6.6";}s:47:"wpvivid-backuprestore/wpvivid-backuprestore.php";O:8:"stdClass":10:{s:2:"id";s:35:"w.org/plugins/wpvivid-backuprestore";s:4:"slug";s:21:"wpvivid-backuprestore";s:6:"plugin";s:47:"wpvivid-backuprestore/wpvivid-backuprestore.php";s:11:"new_version";s:7:"0.9.117";s:3:"url";s:52:"https://wordpress.org/plugins/wpvivid-backuprestore/";s:7:"package";s:72:"https://downloads.wordpress.org/plugin/wpvivid-backuprestore.0.9.117.zip";s:5:"icons";a:2:{s:2:"2x";s:74:"https://ps.w.org/wpvivid-backuprestore/assets/icon-256x256.png?rev=2899202";s:2:"1x";s:74:"https://ps.w.org/wpvivid-backuprestore/assets/icon-128x128.png?rev=2899202";}s:7:"banners";a:2:{s:2:"2x";s:77:"https://ps.w.org/wpvivid-backuprestore/assets/banner-1544x500.png?rev=2899202";s:2:"1x";s:76:"https://ps.w.org/wpvivid-backuprestore/assets/banner-772x250.png?rev=2899202";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.5";}}s:7:"checked";a:2:{s:23:"elementor/elementor.php";s:6:"3.30.3";s:47:"wpvivid-backuprestore/wpvivid-backuprestore.php";s:7:"0.9.117";}}','off');
INSERT INTO `wp_options` VALUES (611,'wpvivid_email_setting','a:3:{s:7:"send_to";a:0:{}s:6:"always";b:1;s:12:"email_enable";b:0;}','off');
INSERT INTO `wp_options` VALUES (612,'wpvivid_compress_setting','a:7:{s:13:"compress_type";s:3:"zip";s:13:"max_file_size";i:200;s:11:"no_compress";b:1;s:13:"use_temp_file";i:1;s:13:"use_temp_size";i:16;s:17:"exclude_file_size";i:0;s:24:"subpackage_plugin_upload";b:0;}','off');
INSERT INTO `wp_options` VALUES (613,'wpvivid_local_setting','a:2:{s:4:"path";s:14:"wpvividbackups";s:10:"save_local";i:1;}','off');
INSERT INTO `wp_options` VALUES (614,'wpvivid_upload_setting','a:1:{s:15:"remote_selected";a:0:{}}','off');
INSERT INTO `wp_options` VALUES (615,'wpvivid_common_setting','a:10:{s:18:"max_execution_time";i:300;s:17:"log_save_location";s:26:"wpvividbackups\\wpvivid_log";s:16:"max_backup_count";i:3;s:14:"show_admin_bar";b:1;s:14:"domain_include";b:1;s:15:"estimate_backup";b:1;s:16:"max_resume_count";i:6;s:12:"memory_limit";s:4:"512M";s:20:"restore_memory_limit";s:4:"512M";s:12:"migrate_size";s:4:"2048";}','off');
INSERT INTO `wp_options` VALUES (616,'wpvivid_init','init','off');
INSERT INTO `wp_options` VALUES (617,'wpvivid_backup_list','a:0:{}','off');
INSERT INTO `wp_options` VALUES (618,'wpvivid_remote_init','init','off');
INSERT INTO `wp_options` VALUES (620,'wpvivid_check_htaccess_rule_free','1','off');
INSERT INTO `wp_options` VALUES (621,'wpvivid_need_review','not','off');
INSERT INTO `wp_options` VALUES (623,'clean_task','a:1:{i:0;b:0;}','off');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

