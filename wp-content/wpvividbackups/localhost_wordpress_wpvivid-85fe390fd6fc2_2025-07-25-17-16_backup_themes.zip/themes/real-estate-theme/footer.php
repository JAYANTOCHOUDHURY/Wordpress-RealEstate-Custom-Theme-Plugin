<footer class="site-footer">
  <div class="container">
    <p>&copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
  </div>
  <?php wp_footer(); ?>
  <script>
  document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.getElementById("menu-toggle");
    const mobileMenu = document.getElementById("mobile-menu");
    const closeMenu = document.getElementById("close-menu");
    const overlay = document.getElementById("menu-overlay");

    const filterForm = document.querySelector(".property-filter");
    const pagination = document.querySelector(".pagination");

    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if(entry.Intersecting){
          entry.target.classList.add("visible");
        }
      });
    }, {
      threshold: 0.2
    });

    if (filterForm){
      observer.observe(filterForm);
    }

    if (pagination){
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting){
            pagination.classList.add("visible");
            observer.unobserve(pagination);
          }
        });
      }, {
        threshold: 0.2
      });
      observer.observe(pagination);
    }

    if (menuToggle && mobileMenu && closeMenu && overlay) {
      menuToggle.addEventListener("click", () => {
        mobileMenu.classList.add("active");
        overlay.classList.add("active");
        document.body.style.overflow = "hidden";
      });

      const closeSidebar = () => {
        mobileMenu.classList.remove("active");
        overlay.classList.remove("active");
        document.body.style.overflow = "";
      };

      closeMenu.addEventListener("click", closeSidebar);
      overlay.addEventListener("click", closeSidebar);
    }
  });
</script>

</footer>
</body>
</html>