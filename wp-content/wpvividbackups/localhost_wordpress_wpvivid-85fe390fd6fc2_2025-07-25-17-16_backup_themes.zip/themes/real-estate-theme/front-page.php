<?php
// Redirect if filter params are all empty
if (
  isset($_GET['type'], $_GET['min_price'], $_GET['max_price'], $_GET['sort'], $_GET['keyword']) &&
  empty($_GET['type']) && empty($_GET['min_price']) && empty($_GET['max_price']) &&
  empty($_GET['sort']) && empty($_GET['keyword'])
) {
  wp_redirect(home_url('/'));
  exit;
}
?>

<?php get_header(); ?>

<section class="hero">
  <h2>Find Your Dream Home</h2>
  <p>Browse our listings to find the perfect property.</p>
</section>

<div class="container">

  <!-- Filter Form -->
  <form id="filter-form" method="GET" action="<?php echo esc_url(home_url('/')); ?>" class="property-filter">
    <div class="filter-grid">

      <!-- Property Type -->
      <div class="filter-item">
        <label>Property Type</label>
        <select name="type">
          <option value="">All Types</option>
          <?php
          $terms = get_terms('property_type');
          if (!is_wp_error($terms) && !empty($terms)) {
            foreach ($terms as $term) {
              $selected = (isset($_GET['type']) && $_GET['type'] === $term->slug) ? 'selected' : '';
              echo '<option value="' . esc_attr($term->slug) . '" ' . $selected . '>' . esc_html($term->name) . '</option>';
            }
          } else {
            echo '<option disabled>No property types found</option>';
          }
          ?>
        </select>
      </div>

      <!-- Min Price -->
      <div class="filter-item">
        <label for="min_price">Min Price (₹)</label>
        <input type="number" name="min_price" id="min_price" value="<?php echo esc_attr($_GET['min_price'] ?? ''); ?>">
      </div>

      <!-- Max Price -->
      <div class="filter-item">
        <label for="max_price">Max Price (₹)</label>
        <input type="number" name="max_price" id="max_price" value="<?php echo esc_attr($_GET['max_price'] ?? ''); ?>">
      </div>

      <!-- Sort -->
      <div class="filter-item">
        <label for="sort">Sort</label>
        <select name="sort" id="sort">
          <option value="">Sort By</option>
          <option value="low" <?php selected($_GET['sort'] ?? '', 'low'); ?>>Price: Low to High</option>
          <option value="high" <?php selected($_GET['sort'] ?? '', 'high'); ?>>Price: High to Low</option>
        </select>
      </div>

      <!-- Keyword -->
      <div class="filter-item">
        <label for="keyword">Keyword</label>
        <input type="text" name="keyword" id="keyword" placeholder="Search..." value="<?php echo esc_attr($_GET['keyword'] ?? ''); ?>">
      </div>

      <!-- Featured Only Checkbox -->
      <div class="filter-item">
        <label>
          <input type="checkbox" name="featured_only" value="1" <?php checked(isset($_GET['featured_only'])); ?> />
          Featured Only
        </label>
      </div>  
    </div>

    <div class="filter-actions">
      <button type="submit">Apply Filters</button>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="clear-filters">Clear Filters</a>
    </div>
  </form>

  <!-- Featured Section -->
  <?php if (empty($_GET)): ?>
    <h2>Featured Properties</h2>
    <div class="property-grid">
      <?php
      $featured_args = array(
        'post_type' => 'property',
        'posts_per_page' => 3,
        'meta_key' => '_is_featured',
        'meta_value' => '1',
      );
      $featured = new WP_Query($featured_args);
      while ($featured->have_posts()): $featured->the_post();
        get_template_part('template-parts/property-card');
      endwhile;
      wp_reset_postdata();
      ?>
    </div>
  <?php endif; ?>

  <!-- Latest or Filtered Properties -->
  <h2><?php echo empty($_GET) ? 'Latest Properties' : 'Filtered Properties'; ?></h2>

  <!-- Update: AJAX target container -->
  <div class="property-grid" id="property-results">
    <?php
    $paged = get_query_var('paged') ?: 1;
    $args = array(
      'post_type' => 'property',
      'posts_per_page' => 6,
      'paged' => $paged,
    );

    // Taxonomy Filter
    if (!empty($_GET['type'])) {
      $args['tax_query'] = array(array(
        'taxonomy' => 'property_type',
        'field' => 'slug',
        'terms' => sanitize_text_field($_GET['type']),
      ));
    }

    // Meta Filters
    $meta_query = array('relation' => 'AND');

    if (!empty($_GET['min_price'])) {
      $meta_query[] = array(
        'key' => '_price',
        'value' => (int) $_GET['min_price'],
        'compare' => '>=',
        'type' => 'NUMERIC',
      );
    }

    if (!empty($_GET['max_price'])) {
      $meta_query[] = array(
        'key' => '_price',
        'value' => (int) $_GET['max_price'],
        'compare' => '<=',
        'type' => 'NUMERIC',
      );
    }

    // Check for Featured Only filter
    if (isset($_GET['featured_only']) && $_GET['featured_only'] == '1') {
      $meta_query[] = array(
        'key' => '_is_featured',
        'value' => '1',
      );
    }

    if (count($meta_query) > 1) {
      $args['meta_query'] = $meta_query;
    }

    // Keyword search
    if (!empty($_GET['keyword'])) {
      $args['s'] = sanitize_text_field($_GET['keyword']);
    }

    // Sort by price
    if (!empty($_GET['sort'])) {
      $args['orderby'] = 'meta_value_num';
      $args['meta_key'] = '_price';
      $args['order'] = ($_GET['sort'] === 'high') ? 'DESC' : 'ASC';
    }

    $properties = new WP_Query($args);

    if ($properties->have_posts()):
      while ($properties->have_posts()): $properties->the_post();
        get_template_part('template-parts/property-card');
      endwhile;

      // Pagination
      echo '<div class="pagination">';
      echo paginate_links(array(
        'total' => $properties->max_num_pages,
        'current' => $paged,
        'format' => '?paged=%#%',
      ));
      echo '</div>';
    else:
      echo '<p>No properties found.</p>';
    endif;

    wp_reset_postdata();
    ?>
  </div> <!-- End property-results -->

</div> <!-- End container -->

<!-- Animation Script -->
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const filter = document.querySelector(".property-filter");
    if (filter) {
      filter.classList.add("visible");
    }

    const pagination = document.querySelector(".pagination");
    if (pagination) {
      pagination.classList.add("visible");
    }
  });
</script>

<?php get_footer(); ?>
