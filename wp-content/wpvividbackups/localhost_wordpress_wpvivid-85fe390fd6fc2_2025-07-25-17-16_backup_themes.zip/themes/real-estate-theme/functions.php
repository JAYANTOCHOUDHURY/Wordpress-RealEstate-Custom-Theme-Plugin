<?php
// Enqueue Styles and Scripts
function realestate_theme_scripts() {
  wp_enqueue_style('style', get_stylesheet_uri());
  wp_enqueue_style('custom-css', get_template_directory_uri() . '/assets/css/style.css');
  wp_enqueue_script('custom-js', get_template_directory_uri() . '/assets/js/script.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'realestate_theme_scripts');

// Theme Setup
function realestate_theme_setup() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_image_size('admin-thumb', 60, 60, true); // ✅ Add square thumb size for admin

  register_nav_menus(array(
    'main-menu'   => __('Main Menu'),
    'mobile-menu' => __('Mobile Menu')
  ));
}
add_action('after_setup_theme', 'realestate_theme_setup');

// Register Custom Post Type: Property
function realestate_register_property_post_type() {
  register_post_type('property', array(
    'labels' => array(
      'name' => 'Properties',
      'singular_name' => 'Property',
    ),
    'public' => true,
    'has_archive' => true,
    'rewrite' => array('slug' => 'properties'),
    'supports' => array('title', 'editor', 'thumbnail'),
    'menu_icon' => 'dashicons-admin-home',
  ));
}
add_action('init', 'realestate_register_property_post_type');

// Register Taxonomy: Property Type
function realestate_register_property_taxonomies() {
  register_taxonomy('property_type', 'property', array(
    'labels' => array(
      'name' => 'Property Types',
      'singular_name' => 'Property Type',
    ),
    'hierarchical' => true,
    'public' => true,
    'show_ui' => true,
    'show_admin_column' => true,
    'rewrite' => array('slug' => 'type'),
  ));
}
add_action('init', 'realestate_register_property_taxonomies');

// Add Meta Box: Property Details
function realestate_add_custom_meta_box() {
  add_meta_box('property_details', 'Property Details', 'realestate_display_custom_fields', 'property', 'normal', 'high');
}
add_action('add_meta_boxes', 'realestate_add_custom_meta_box');

function realestate_display_custom_fields($post) {
  $price = get_post_meta($post->ID, '_price', true);
  $location = get_post_meta($post->ID, '_location', true);
  $status = get_post_meta($post->ID, '_status', true);
  $area = get_post_meta($post->ID, '_area', true);
  $map_embed = get_post_meta($post->ID, '_map_embed', true);
  $contact_email = get_post_meta($post->ID, '_contact_email', true);
  ?>
  <label><strong>Price:</strong></label><br>
  <input type="text" name="property_price" value="<?php echo esc_attr($price); ?>" style="width:100%;"><br><br>

  <label><strong>Location:</strong></label><br>
  <input type="text" name="property_location" value="<?php echo esc_attr($location); ?>" style="width:100%;"><br><br>

  <label><strong>Status:</strong></label><br>
  <select name="property_status" style="width:100%;">
    <option value="Ready to Move" <?php selected($status, 'Ready to Move'); ?>>Ready to Move</option>
    <option value="Under Construction" <?php selected($status, 'Under Construction'); ?>>Under Construction</option>
  </select><br><br>

  <label><strong>Area (sqft):</strong></label><br>
  <input type="text" name="property_area" value="<?php echo esc_attr($area); ?>" style="width:100%;"><br><br>

  <label><strong>Google Maps Embed Code:</strong></label><br>
  <textarea name="property_map_embed" id="property_map_embed" rows="4" style="width:100%;"><?php echo esc_textarea(get_post_meta($post->ID, '_map_embed', true)); ?></textarea><br><br>

  <label><strong>Contact Email (Agent):</strong></label><br>
  <input type="email" name="property_contact_email" value="<?php echo esc_attr(get_post_meta($post->ID, '_contact_email', true)); ?>" style="width:100%;"><br><br>
  <?php
}

function realestate_save_custom_fields($post_id) {
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

  if (isset($_POST['property_price'])) {
    update_post_meta($post_id, '_price', sanitize_text_field($_POST['property_price']));
  }
  if (isset($_POST['property_location'])) {
    update_post_meta($post_id, '_location', sanitize_text_field($_POST['property_location']));
  }
  if (isset($_POST['property_status'])) {
    update_post_meta($post_id, '_status', sanitize_text_field($_POST['property_status']));
  }
  if (isset($_POST['property_area'])) {
    update_post_meta($post_id, '_area', sanitize_text_field($_POST['property_area']));
  }
  if (isset($_POST['property_map_embed'])) {
    update_post_meta($post_id, '_map_embed', sanitize_textarea_field($_POST['property_map_embed']));
  }
  if (isset($_POST['property_contact_email'])) {
    update_post_meta($post_id, '_contact_email', sanitize_email($_POST['property_contact_email']));
  }
}
add_action('save_post', 'realestate_save_custom_fields');

// Add Meta Box: Featured Property
function realestate_add_featured_meta_box() {
  add_meta_box('realestate_featured', 'Featured Property', 'realestate_featured_field_callback', 'property');
}
add_action('add_meta_boxes', 'realestate_add_featured_meta_box');

function realestate_featured_field_callback($post) {
  $is_featured = get_post_meta($post->ID, '_is_featured', true);
  ?>
  <label>
    <input type="checkbox" name="realestate_is_featured" value="1" <?php checked($is_featured, '1'); ?> />
    Mark as Featured
  </label>
  <?php
}

function realestate_save_featured_meta($post_id) {
  $is_featured = isset($_POST['realestate_is_featured']) ? '1' : '';
  update_post_meta($post_id, '_is_featured', $is_featured);
}
add_action('save_post', 'realestate_save_featured_meta');

// Register meta box for property gallery
function property_gallery_meta_box() {
  add_meta_box(
    'property_gallery',
    'Property Gallery',
    'property_gallery_callback',
    'property',
    'normal',
    'high'
  );
}
add_action('add_meta_boxes', 'property_gallery_meta_box');

function property_gallery_callback($post) {
  wp_nonce_field('property_gallery_nonce_action', 'property_gallery_nonce');

  $gallery = get_post_meta($post->ID, '_property_gallery', true);

  if (!empty($gallery) && is_string($gallery)) {
    $image_ids = array_filter(explode(',', $gallery));
  } elseif (is_array($gallery)) {
    $image_ids = $gallery;
  } else {
    $image_ids = [];
  }

  echo '<div>';
  echo '<a href="#" class="upload-gallery button">Add Gallery Images</a>';
  echo '<div id="gallery-preview" style="margin-top:10px;">';

  if (!empty($image_ids)) {
    foreach ($image_ids as $image_id) {
      $thumb_url = wp_get_attachment_thumb_url($image_id);
      if ($thumb_url) {
        echo '<img src="' . esc_url($thumb_url) . '" style="max-width:100px;margin:5px;">';
      }
    }
  }

  echo '</div>';
  echo '<input type="hidden" name="property_gallery" id="property_gallery" value="' . esc_attr(implode(',', $image_ids)) . '">';
  echo '</div>';
}

function save_property_gallery($post_id) {
  if (!isset($_POST['property_gallery_nonce']) || !wp_verify_nonce($_POST['property_gallery_nonce'], 'property_gallery_nonce_action')) {
    return $post_id;
  }

  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return $post_id;
  if (!current_user_can('edit_post', $post_id)) return $post_id;

  if (isset($_POST['property_gallery'])) {
    $gallery_ids = sanitize_text_field($_POST['property_gallery']);
    update_post_meta($post_id, '_property_gallery', $gallery_ids);
  } else {
    delete_post_meta($post_id, '_property_gallery');
  }
}
add_action('save_post', 'save_property_gallery');

function enqueue_property_gallery_scripts($hook) {
  if ($hook === 'post.php' || $hook === 'post-new.php') {
    wp_enqueue_media();
    wp_enqueue_script('property-gallery', get_template_directory_uri() . '/assets/js/property-gallery.js', array('jquery'), null, true);
  }
}
add_action('admin_enqueue_scripts', 'enqueue_property_gallery_scripts');

// Admin columns for property list
function custom_property_columns($columns) {
  $new_columns = array();
  $new_columns['cb'] = $columns['cb'];
  $new_columns['title'] = __('Title');
  $new_columns['price'] = __('Price (₹)');
  $new_columns['property_type'] = __('Property Type');
  $new_columns['thumbnail'] = __('Image');
  return $new_columns;
}
add_filter('manage_property_posts_columns', 'custom_property_columns');

function custom_property_column_content($column, $post_id) {
  switch ($column) {
    case 'price':
      $price = get_post_meta($post_id, '_price', true);
      $numeric_price = (float) str_replace(',', '', $price);
      echo '₹ ' . number_format($numeric_price);
      break;
    case 'property_type':
      $terms = get_the_terms($post_id, 'property_type');
      if (!empty($terms) && !is_wp_error($terms)) {
        $term_names = wp_list_pluck($terms, 'name');
        echo esc_html(implode(', ', $term_names));
      } else {
        echo '—';
      }
      break;
    case 'thumbnail':
      if (has_post_thumbnail($post_id)) {
        echo get_the_post_thumbnail($post_id, 'admin-thumb');
      } else {
        echo '—';
      }
      break;
  }
}
add_action('manage_property_posts_custom_column', 'custom_property_column_content', 10, 2);

function custom_property_sortable_columns($columns) {
  $columns['price'] = 'price';
  return $columns;
}
add_filter('manage_edit-property_sortable_columns', 'custom_property_sortable_columns');

function custom_property_orderby($query) {
  if (!is_admin() || !$query->is_main_query()) return;

  if ($query->get('orderby') === 'price') {
    $query->set('meta_key', '_price');
    $query->set('orderby', 'meta_value_num');
  }
}
add_action('pre_get_posts', 'custom_property_orderby');

function handle_property_contact_form() {
  if (
    isset($_POST['property_id'], $_POST['to_email'], $_POST['user_name'], $_POST['user_email'], $_POST['user_message'])
  ) {
    $property_id = absint($_POST['property_id']);
    $to = sanitize_email($_POST['to_email']);
    $user_name = sanitize_text_field($_POST['user_name']);
    $user_email = sanitize_email($_POST['user_email']);
    $user_message = sanitize_textarea_field($_POST['user_message']);
    $property_title = get_the_title($property_id);
    $property_link = get_permalink($property_id);

    // Email
    $subject = 'Property Inquiry from ' . $user_name;
    $message = "Name: " . $user_name . "\n";
    $message .= "Email: " . $user_email . "\n\n";
    $message .= "Message:\n" . $user_message . "\n\n";
    $message .= "Property: " . $property_title . "\n";
    $message .= "Link: " . $property_link;
    $headers = ['Content-Type: text/plain; charset=UTF-8'];

    wp_mail($to, $subject, $message, $headers);
    $post_data = array(
      'post_title'   => 'Inquiry from ' . $user_name . ' – Property: ' . $property_title,
      'post_type'    => 'inquiry',
      'post_status'  => 'publish',
      'post_content' => "Name: $user_name\nEmail: $user_email\n\nMessage:\n$user_message\n\nProperty: $property_title\nLink: $property_link",
    );
    wp_insert_post($post_data);
  }
}
add_action('template_redirect', 'handle_property_contact_form');

// Register Inquiry CPT
function realestate_register_inquiry_post_type() {
  register_post_type('inquiry', array(
    'labels' => array(
      'name' => 'Inquiries',
      'singular_name' => 'Inquiry',
    ),
    'public' => false,
    'show_ui' => true,
    'supports' => array('title', 'editor'),
    'menu_icon' => 'dashicons-email',
  ));
}
add_action('init', 'realestate_register_inquiry_post_type');


