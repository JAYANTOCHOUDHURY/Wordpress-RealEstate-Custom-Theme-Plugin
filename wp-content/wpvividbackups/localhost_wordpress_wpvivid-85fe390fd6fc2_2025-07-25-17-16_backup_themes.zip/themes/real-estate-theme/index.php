<?php get_header(); 
get_template_part('front-page'); ?>

<main>
  <h1>Welcome to Our Real Estate Site</h1>
</main>

<?php get_footer(); ?>
