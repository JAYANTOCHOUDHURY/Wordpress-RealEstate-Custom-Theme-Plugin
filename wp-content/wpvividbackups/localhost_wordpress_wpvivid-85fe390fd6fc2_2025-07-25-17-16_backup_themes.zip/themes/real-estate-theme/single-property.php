<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_name'], $_POST['user_email'], $_POST['user_message'])) {
  $name    = sanitize_text_field($_POST['user_name']);
  $email   = sanitize_email($_POST['user_email']);
  $message = sanitize_textarea_field($_POST['user_message']);
  $property_id = intval($_POST['property_id']);
  $to_email = sanitize_email($_POST['to_email']);

  // Save to admin
  $inquiry_post_id = wp_insert_post(array(
    'post_type'   => 'inquiry',
    'post_title'  => 'Inquiry from ' . $name,
    'post_content'=> "Name: $name\nEmail: $email\nMessage:\n$message",
    'post_status' => 'publish'
  ));

  // Email
  $subject = 'New Property Inquiry';
  $body = "You have received a new inquiry:\n\nProperty: " . get_the_title($property_id) . "\nName: $name\nEmail: $email\nMessage:\n$message";
  $headers = array('Content-Type: text/plain; charset=UTF-8');

  wp_mail($to_email, $subject, $body, $headers);

  // Optional: redirect or show success
  echo '<div class="success-message">Your inquiry has been sent!</div>';
}
?>

<?php get_header(); ?>

<main class="single-property">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <div class="container property-card">
      <h1 class="property-title"><?php the_title(); ?></h1>

      <?php if (has_post_thumbnail()) : ?>
        <div class="property-image">
          <?php the_post_thumbnail('large'); ?>
        </div>
      <?php endif; ?>

      <?php
      // Get gallery meta field
      $gallery = get_post_meta(get_the_ID(), '_property_gallery', true);

      // Ensure $image_ids is always an array
      if (!empty($gallery) && is_string($gallery)) {
        $image_ids = array_filter(explode(',', $gallery));
      } elseif (is_array($gallery)) {
        $image_ids = $gallery;
      } else {
        $image_ids = [];
      }

      if (!empty($image_ids)) {
        echo '<div class="property-gallery">';
        foreach ($image_ids as $image_id) {
          echo '<img src="' . esc_url(wp_get_attachment_image_url($image_id, 'large')) . '" class="gallery-image" />';
        }
        echo '</div>';
      }
      ?>

      <ul class="property-meta">
        <li><strong>Price:</strong> <?php echo esc_html(get_post_meta(get_the_ID(), '_price', true)); ?></li>
        <li><strong>Location:</strong> <?php echo esc_html(get_post_meta(get_the_ID(), '_location', true)); ?></li>
        <li><strong>Status:</strong> <?php echo esc_html(get_post_meta(get_the_ID(), '_status', true)); ?></li>
        <li><strong>Area:</strong> <?php echo esc_html(get_post_meta(get_the_ID(), '_area', true)); ?> sqft</li>
        <li><strong>Type:</strong>
          <?php
          $terms = get_the_terms(get_the_ID(), 'property_type');
          if ($terms && !is_wp_error($terms)) {
            $types = wp_list_pluck($terms, 'name');
            echo esc_html(implode(', ', $types));
          }
          ?>
        </li>
      </ul>

      <div class="property-content">
        <?php the_content(); ?>
      </div>

      <?php
      // Get map and contact info
      $map_embed = get_post_meta(get_the_ID(), '_map_embed', true);
      $contact_email = get_post_meta(get_the_ID(), '_contact_email', true);
      ?>

      <?php if ($map_embed): ?>
        <div class="property-map" style="margin-top:30px;">
          <h3>Location</h3>
          <div class="map-embed" style="width:100%;height:auto;">
            <?php echo $map_embed; ?>
          </div>
        </div>
      <?php endif; ?>

      <?php if ($contact_email): ?>
        <div class="property-contact-form" style="margin-top:30px;">
          <h3>Contact Agent</h3>
          <form method="post" action="">
            <input type="hidden" name="property_id" value="<?php echo get_the_ID(); ?>">
            <input type="hidden" name="to_email" value="<?php echo esc_attr($contact_email); ?>">
            <input type="text" name="user_name" placeholder="Your Name" required>
            <input type="email" name="user_email" placeholder="Your Email" required>
            <textarea name="user_message" placeholder="Your Message" required></textarea>
            <button type="submit">Send Inquiry</button>
          </form>
        </div>
      <?php endif; ?>

    </div>
  <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>
