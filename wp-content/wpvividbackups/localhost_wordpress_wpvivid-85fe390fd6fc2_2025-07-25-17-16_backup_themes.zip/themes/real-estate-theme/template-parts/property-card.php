<div class="property-card">
  <?php if (has_post_thumbnail()): ?>
    <div class="property-thumbnail">
      <a href="<?php the_permalink(); ?>">
        <?php the_post_thumbnail('medium'); ?>
      </a>
    </div>
  <?php endif; ?>

  <div class="property-details">
    <h3 class="property-title"><?php the_title(); ?></h3>

    <?php
    $terms = get_the_terms(get_the_ID(), 'property_type');
    if ($terms && !is_wp_error($terms)) {
      $types = wp_list_pluck($terms, 'name');
      echo '<p class="property-type">' . implode(', ', $types) . '</p>';
    }

    $price = get_post_meta(get_the_ID(), '_price', true);
    $location = get_post_meta(get_the_ID(), '_location', true);
    $area = get_post_meta(get_the_ID(), '_area', true);
    ?>

    <ul class="property-meta">
      <?php if ($price): ?>
        <li><strong>Price:</strong> ₹<?php echo esc_html($price); ?></li>
      <?php endif; ?>
      <?php if ($location): ?>
        <li><strong>Location:</strong> <?php echo esc_html($location); ?></li>
      <?php endif; ?>
      <?php if ($area): ?>
        <li><strong>Area:</strong> <?php echo esc_html($area); ?> sqft</li>
      <?php endif; ?>
    </ul>

    <a href="<?php the_permalink(); ?>" class="view-button">View Details</a>
  </div>
</div>